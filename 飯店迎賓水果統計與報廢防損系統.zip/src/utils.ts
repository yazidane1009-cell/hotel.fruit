/**
 * @license
 * SPDX-License-Identifier: Apache-2.0
 */

import { LogEntry, FruitType, DEFAULT_FRUITS } from './types';

// Format currency to standard NTD / Currency format
export function formatCurrency(amount: number): string {
  return new Intl.NumberFormat('zh-TW', {
    style: 'currency',
    currency: 'TWD',
    minimumFractionDigits: 0,
    maximumFractionDigits: 0,
  }).format(amount);
}

// Format timestamp to date string (e.g., 2026-07-16 10:30)
export function formatDateTime(timestamp: number): string {
  const date = new Date(timestamp);
  const y = date.getFullYear();
  const m = String(date.getMonth() + 1).padStart(2, '0');
  const d = String(date.getDate()).padStart(2, '0');
  const h = String(date.getHours()).padStart(2, '0');
  const min = String(date.getMinutes()).padStart(2, '0');
  return `${y}-${m}-${d} ${h}:${min}`;
}

// Format date to short string (e.g., 07-16)
export function formatDateShort(timestamp: number): string {
  const date = new Date(timestamp);
  const m = String(date.getMonth() + 1).padStart(2, '0');
  const d = String(date.getDate()).padStart(2, '0');
  return `${m}/${d}`;
}

// Generate CSV string from logs and download it
export function exportToCSV(logs: LogEntry[], fruits: FruitType[]) {
  const fruitMap = new Map(fruits.map(f => [f.id, f]));
  
  // Header row
  const headers = ['記錄時間', '水果名稱', '記錄類型', '數量', '單位', '估計成本(TWD)', '報廢原因', '備註'];
  
  const rows = logs.map(log => {
    const fruit = fruitMap.get(log.fruitId);
    const fruitName = fruit ? fruit.name : '未知水果';
    const unit = fruit ? fruit.unit : '';
    
    let typeStr = '';
    if (log.type === 'supply') typeStr = '補貨上架';
    else if (log.type === 'consumption') typeStr = '顧客食用';
    else if (log.type === 'wastage') typeStr = '報廢清理';
    
    return [
      formatDateTime(log.timestamp),
      fruitName,
      typeStr,
      log.quantity,
      unit,
      log.cost,
      log.reason || '',
      log.notes || ''
    ];
  });
  
  const csvContent = [
    '\uFEFF' + headers.join(','), // Include BOM for proper Excel display
    ...rows.map(row => row.map(cell => {
      // Escape commas and double quotes
      const str = String(cell).replace(/"/g, '""');
      return str.includes(',') || str.includes('\n') || str.includes('"') ? `"${str}"` : str;
    }).join(','))
  ].join('\n');
  
  const blob = new Blob([csvContent], { type: 'text/csv;charset=utf-8;' });
  const url = URL.createObjectURL(blob);
  const link = document.createElement('a');
  link.setAttribute('href', url);
  link.setAttribute('download', `飯店大廳迎賓水果統計報表_${new Date().toISOString().split('T')[0]}.csv`);
  document.body.appendChild(link);
  link.click();
  document.body.removeChild(link);
}

// Export raw JSON backup
export function exportToJSON(logs: LogEntry[], fruits: FruitType[]) {
  const backup = {
    version: '1.0',
    exportDate: new Date().toISOString(),
    fruits,
    logs
  };
  
  const blob = new Blob([JSON.stringify(backup, null, 2)], { type: 'application/json' });
  const url = URL.createObjectURL(blob);
  const link = document.createElement('a');
  link.setAttribute('href', url);
  link.setAttribute('download', `迎賓水果統計備份_${new Date().toISOString().split('T')[0]}.json`);
  document.body.appendChild(link);
  link.click();
  document.body.removeChild(link);
}

// Generate rich mock data for the past 90 days to make charts populated and beautiful
export function generateMockData(): { logs: LogEntry[], fruits: FruitType[] } {
  const fruits = [...DEFAULT_FRUITS];
  const logs: LogEntry[] = [];
  const now = Date.now();
  const ONE_DAY = 24 * 60 * 60 * 1000;
  
  // Seed random generator to keep it consistent but realistic
  let seed = 42;
  function random() {
    const x = Math.sin(seed++) * 10000;
    return x - Math.floor(x);
  }

  // Generate logs for the past 90 days
  for (let d = 90; d >= 0; d--) {
    const dayTimestamp = now - d * ONE_DAY;
    const date = new Date(dayTimestamp);
    
    // Different days have different occupancy/weekend traffic
    // Weekends (Fri, Sat, Sun) have higher guest traffic
    const dayOfWeek = date.getDay();
    const isWeekend = dayOfWeek === 0 || dayOfWeek === 5 || dayOfWeek === 6;
    const trafficMultiplier = isWeekend ? 1.5 : 0.8;
    
    fruits.forEach(fruit => {
      // 1. Supply: Every morning around 08:00
      const supplyHour = 8;
      const supplyTime = new Date(dayTimestamp);
      supplyTime.setHours(supplyHour, Math.floor(random() * 30), 0, 0);
      
      // Calculate daily supply amount based on fruit popularity
      let baseSupply = 15;
      if (fruit.id === 'apple') baseSupply = 20;
      if (fruit.id === 'banana') baseSupply = 25;
      if (fruit.id === 'grape') baseSupply = 5; // unit is string (串)
      
      const supplyQty = Math.round(baseSupply * trafficMultiplier * (0.8 + random() * 0.4));
      const supplyCost = supplyQty * fruit.defaultCost;
      
      logs.push({
        id: `mock-supply-${fruit.id}-${d}`,
        timestamp: supplyTime.getTime(),
        fruitId: fruit.id,
        type: 'supply',
        quantity: supplyQty,
        cost: supplyCost,
        notes: '每日早班例行鋪貨'
      });

      // 2. Consumption: Guest eating, recorded at afternoon/evening
      // Naturally, consumption is less than or equal to supply + leftover
      // Popular fruits (banana, apple) get consumed more
      let baseConsumeRate = 0.75; // 75% consumed
      if (fruit.id === 'pear') baseConsumeRate = 0.5; // pear is slower
      if (fruit.id === 'banana') baseConsumeRate = 0.85; // banana is popular
      
      const consumeQty = Math.round(supplyQty * baseConsumeRate * (0.7 + random() * 0.4));
      const actualConsume = Math.min(consumeQty, supplyQty);
      
      const consumeTime1 = new Date(dayTimestamp);
      consumeTime1.setHours(14, Math.floor(random() * 45), 0, 0);
      
      logs.push({
        id: `mock-consume-1-${fruit.id}-${d}`,
        timestamp: consumeTime1.getTime(),
        fruitId: fruit.id,
        type: 'consumption',
        quantity: Math.floor(actualConsume * 0.4),
        cost: Math.floor(actualConsume * 0.4) * fruit.defaultCost,
        notes: '午下午茶時段統計'
      });

      const consumeTime2 = new Date(dayTimestamp);
      consumeTime2.setHours(20, Math.floor(random() * 45), 0, 0);
      
      logs.push({
        id: `mock-consume-2-${fruit.id}-${d}`,
        timestamp: consumeTime2.getTime(),
        fruitId: fruit.id,
        type: 'consumption',
        quantity: Math.ceil(actualConsume * 0.6),
        cost: Math.ceil(actualConsume * 0.6) * fruit.defaultCost,
        notes: '晚間迎賓時段統計'
      });

      // 3. Wastage: Leftover that got spoiled, checked late night or next morning
      // Let's say 5-15% of fruits gets wasted
      const leftover = supplyQty - actualConsume;
      if (leftover > 0) {
        const wasteRate = fruit.id === 'banana' ? 0.6 : 0.3; // banana spoils faster
        const wasteQty = Math.round(leftover * wasteRate);
        
        if (wasteQty > 0) {
          const wasteTime = new Date(dayTimestamp);
          wasteTime.setHours(22, 30 + Math.floor(random() * 20), 0, 0);
          
          const reasons = [
            '過熟變軟 (Overripe)',
            '碰撞受損 (Bruised)',
            '表面發霉 (Moldy)',
            '例行清理更換 (Routine Replacement)'
          ];
          const reasonIdx = Math.floor(random() * reasons.length);
          
          logs.push({
            id: `mock-waste-${fruit.id}-${d}`,
            timestamp: wasteTime.getTime(),
            fruitId: fruit.id,
            type: 'wastage',
            quantity: wasteQty,
            cost: wasteQty * fruit.defaultCost,
            reason: reasons[reasonIdx],
            notes: '夜班清點報廢'
          });
        }
      }
    });
  }
  
  return { logs, fruits };
}
