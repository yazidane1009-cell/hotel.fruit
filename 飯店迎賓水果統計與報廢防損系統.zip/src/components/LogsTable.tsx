/**
 * @license
 * SPDX-License-Identifier: Apache-2.0
 */

import React, { useState, useMemo } from 'react';
import { LogEntry, FruitType } from '../types';
import { formatDateTime, formatCurrency } from '../utils';
import { Search, Filter, Trash2, ChevronLeft, ChevronRight, Download, Upload } from 'lucide-react';

interface LogsTableProps {
  logs: LogEntry[];
  fruits: FruitType[];
  onDeleteLog: (id: string) => void;
  onExportCSV: () => void;
  onExportJSON: () => void;
  onImportJSON: (event: React.ChangeEvent<HTMLInputElement>) => void;
}

export default function LogsTable({
  logs,
  fruits,
  onDeleteLog,
  onExportCSV,
  onExportJSON,
  onImportJSON,
}: LogsTableProps) {
  // Filters & Search
  const [searchQuery, setSearchQuery] = useState('');
  const [typeFilter, setTypeFilter] = useState<string>('all');
  const [fruitFilter, setFruitFilter] = useState<string>('all');
  
  // Pagination
  const [currentPage, setCurrentPage] = useState(1);
  const itemsPerPage = 8;

  const fruitMap = useMemo(() => new Map(fruits.map(f => [f.id, f])), [fruits]);

  // Filter logs
  const filteredLogs = useMemo(() => {
    return logs
      .filter(log => {
        // 1. Filter by Log Type
        if (typeFilter !== 'all' && log.type !== typeFilter) return false;
        
        // 2. Filter by Fruit Type
        if (fruitFilter !== 'all' && log.fruitId !== fruitFilter) return false;
        
        // 3. Search query match
        if (searchQuery.trim() !== '') {
          const fruit = fruitMap.get(log.fruitId);
          const fruitName = fruit ? fruit.name : '';
          const notesMatch = log.notes?.toLowerCase().includes(searchQuery.toLowerCase()) || false;
          const reasonMatch = log.reason?.toLowerCase().includes(searchQuery.toLowerCase()) || false;
          const fruitMatch = fruitName.toLowerCase().includes(searchQuery.toLowerCase());
          return notesMatch || reasonMatch || fruitMatch;
        }
        
        return true;
      })
      // Newest logs first
      .sort((a, b) => b.timestamp - a.timestamp);
  }, [logs, typeFilter, fruitFilter, searchQuery, fruitMap]);

  // Paginated chunk
  const totalPages = Math.max(1, Math.ceil(filteredLogs.length / itemsPerPage));
  const paginatedLogs = useMemo(() => {
    // Reset page if it exceeds bounds
    const page = currentPage > totalPages ? 1 : currentPage;
    const startIndex = (page - 1) * itemsPerPage;
    return filteredLogs.slice(startIndex, startIndex + itemsPerPage);
  }, [filteredLogs, currentPage, totalPages]);

  // Reset pagination on filter change
  const handleTypeChange = (val: string) => {
    setTypeFilter(val);
    setCurrentPage(1);
  };

  const handleFruitChange = (val: string) => {
    setFruitFilter(val);
    setCurrentPage(1);
  };

  const handleSearchChange = (val: string) => {
    setSearchQuery(val);
    setCurrentPage(1);
  };

  return (
    <div id="logs_history_section_card" className="rounded-2xl border border-slate-100 bg-white p-6 shadow-sm">
      {/* Table Header and Actions */}
      <div className="mb-6 flex flex-col justify-between gap-4 border-b border-slate-50 pb-5 sm:flex-row sm:items-center">
        <div>
          <h3 className="text-lg font-semibold text-slate-900">歷史紀錄</h3>
        </div>

        {/* Data Backup Controls */}
        <div className="flex flex-wrap items-center gap-2">
          {/* Hidden File Input for JSON restore */}
          <label className="flex cursor-pointer items-center gap-1.5 rounded-xl border border-slate-200 bg-slate-50 px-3 py-2 text-xs font-semibold text-slate-600 transition hover:bg-slate-100">
            <Upload className="h-3.5 w-3.5" />
            匯入備份
            <input
              id="import_json_input"
              type="file"
              accept=".json"
              onChange={onImportJSON}
              className="hidden"
            />
          </label>
          
          <button
            id="export_json_btn"
            onClick={onExportJSON}
            className="flex items-center gap-1.5 rounded-xl border border-slate-200 bg-slate-50 px-3 py-2 text-xs font-semibold text-slate-600 transition hover:bg-slate-100 cursor-pointer"
          >
            <Download className="h-3.5 w-3.5" />
            備份 JSON
          </button>

          <button
            id="export_csv_btn"
            onClick={onExportCSV}
            className="flex items-center gap-1.5 rounded-xl bg-slate-900 px-3.5 py-2 text-xs font-semibold text-white transition hover:bg-slate-800 shadow-sm cursor-pointer"
          >
            <Download className="h-3.5 w-3.5" />
            匯出 Excel (CSV)
          </button>
        </div>
      </div>

      {/* Search & Filter Controls */}
      <div className="mb-4 grid grid-cols-1 gap-3 sm:grid-cols-3 lg:grid-cols-4">
        {/* Search */}
        <div className="relative">
          <Search className="absolute top-1/2 left-3 h-4 w-4 -translate-y-1/2 text-slate-400" />
          <input
            id="log_search_input"
            type="text"
            placeholder="搜尋關鍵字、備註、水果..."
            value={searchQuery}
            onChange={(e) => handleSearchChange(e.target.value)}
            className="w-full rounded-xl border border-slate-200 bg-slate-50/50 py-2 pl-9 pr-4 text-xs font-medium text-slate-800 transition focus:border-slate-300 focus:bg-white focus:outline-none"
          />
        </div>

        {/* Filter by Log Type */}
        <div className="flex items-center gap-2">
          <Filter className="h-3.5 w-3.5 text-slate-400 shrink-0" />
          <select
            id="filter_log_type"
            value={typeFilter}
            onChange={(e) => handleTypeChange(e.target.value)}
            className="w-full rounded-xl border border-slate-200 bg-slate-50/50 px-3 py-2 text-xs font-medium text-slate-800 transition focus:border-slate-300 focus:bg-white focus:outline-none"
          >
            <option value="all">所有流水類型</option>
            <option value="supply">補貨上架 (Supply)</option>
            <option value="consumption">客人食用 (Consumption)</option>
            <option value="wastage">報廢清理 (Wastage)</option>
          </select>
        </div>

        {/* Filter by Fruit */}
        <div className="flex items-center gap-2">
          <Filter className="h-3.5 w-3.5 text-slate-400 shrink-0" />
          <select
            id="filter_fruit"
            value={fruitFilter}
            onChange={(e) => handleFruitChange(e.target.value)}
            className="w-full rounded-xl border border-slate-200 bg-slate-50/50 px-3 py-2 text-xs font-medium text-slate-800 transition focus:border-slate-300 focus:bg-white focus:outline-none"
          >
            <option value="all">所有水果品項</option>
            {fruits.map(fruit => (
              <option key={fruit.id} value={fruit.id}>
                {fruit.name.split(' ')[0]}
              </option>
            ))}
          </select>
        </div>
      </div>

      {/* Logs Table */}
      <div className="overflow-x-auto rounded-xl border border-slate-100">
        <table className="w-full border-collapse text-left text-xs">
          <thead>
            <tr className="border-b border-slate-100 bg-slate-50/70 font-semibold text-slate-500">
              <th className="p-3.5 font-semibold">紀錄時間</th>
              <th className="p-3.5 font-semibold">流向類型</th>
              <th className="p-3.5 font-semibold">水果品項</th>
              <th className="p-3.5 font-semibold">數量</th>
              <th className="p-3.5 font-semibold">估計成本 / 價值</th>
              <th className="p-3.5 font-semibold">原因及備註</th>
              <th className="p-3.5 text-center font-semibold">操作</th>
            </tr>
          </thead>
          <tbody className="divide-y divide-slate-50 text-slate-700">
            {paginatedLogs.length === 0 ? (
              <tr>
                <td colSpan={7} className="p-8 text-center text-slate-400">
                  沒有符合當前搜尋或篩選條件的迎賓水果紀錄。
                </td>
              </tr>
            ) : (
              paginatedLogs.map((log) => {
                const fruit = fruitMap.get(log.fruitId);
                const fruitName = fruit ? fruit.name : '未知水果';
                const unit = fruit ? fruit.unit : '';
                const color = fruit ? fruit.color : '#cbd5e1';

                return (
                  <tr key={log.id} className="hover:bg-slate-50/50 transition">
                    <td className="p-3.5 text-slate-500 font-medium whitespace-nowrap">
                      {formatDateTime(log.timestamp)}
                    </td>
                    
                    <td className="p-3.5 whitespace-nowrap">
                      {log.type === 'supply' && (
                        <span className="inline-flex items-center gap-1 rounded-full bg-emerald-50 px-2.5 py-1 text-[10px] font-bold text-emerald-700 border border-emerald-100">
                          補貨上架
                        </span>
                      )}
                      {log.type === 'consumption' && (
                        <span className="inline-flex items-center gap-1 rounded-full bg-indigo-50 px-2.5 py-1 text-[10px] font-bold text-indigo-700 border border-indigo-100">
                          顧客食用
                        </span>
                      )}
                      {log.type === 'wastage' && (
                        <span className="inline-flex items-center gap-1 rounded-full bg-rose-50 px-2.5 py-1 text-[10px] font-bold text-rose-700 border border-rose-100">
                          報廢清理
                        </span>
                      )}
                    </td>

                    <td className="p-3.5 font-medium text-slate-800">
                      <div className="flex items-center gap-2">
                        <span className="h-2 w-2 rounded-full shrink-0" style={{ backgroundColor: color }} />
                        <span>{fruitName}</span>
                      </div>
                    </td>

                    <td className="p-3.5 font-semibold text-slate-900">
                      {log.quantity} <span className="text-slate-400 font-normal">{unit}</span>
                    </td>

                    <td className="p-3.5 font-bold text-slate-700">
                      {formatCurrency(log.cost)}
                    </td>

                    <td className="p-3.5 text-slate-500 max-w-xs truncate">
                      {log.type === 'wastage' && log.reason && (
                        <span className="font-bold text-rose-600 block text-[11px] mb-0.5">
                          原因：{log.reason}
                        </span>
                      )}
                      <span className="italic text-slate-400 text-[11px]">
                        {log.notes || '—'}
                      </span>
                    </td>

                    <td className="p-3.5 text-center">
                      <button
                        type="button"
                        onClick={() => {
                          if (confirm(`您確定要刪除這筆水果紀錄嗎？此動作將會立即恢復該水果的庫存量。`)) {
                            onDeleteLog(log.id);
                          }
                        }}
                        className="rounded-lg p-1.5 text-slate-400 hover:bg-rose-50 hover:text-rose-600 transition cursor-pointer"
                        title="刪除此筆記錄"
                      >
                        <Trash2 className="h-4 w-4" />
                      </button>
                    </td>
                  </tr>
                );
              })
            )}
          </tbody>
        </table>
      </div>

      {/* Pagination Footer */}
      {totalPages > 1 && (
        <div className="mt-4 flex items-center justify-between border-t border-slate-50 pt-4">
          <p className="text-xs text-slate-400">
            顯示第 {((currentPage - 1) * itemsPerPage) + 1} 至 {Math.min(currentPage * itemsPerPage, filteredLogs.length)} 筆，共 {filteredLogs.length} 筆
          </p>
          <div className="flex items-center gap-1.5">
            <button
              onClick={() => setCurrentPage(prev => Math.max(1, prev - 1))}
              disabled={currentPage === 1}
              className="flex h-8 w-8 items-center justify-center rounded-lg border border-slate-100 text-slate-500 hover:bg-slate-50 disabled:opacity-40 disabled:hover:bg-transparent"
            >
              <ChevronLeft className="h-4 w-4" />
            </button>
            <span className="text-xs font-semibold text-slate-700 px-2">
              {currentPage} / {totalPages} 頁
            </span>
            <button
              onClick={() => setCurrentPage(prev => Math.min(totalPages, prev + 1))}
              disabled={currentPage === totalPages}
              className="flex h-8 w-8 items-center justify-center rounded-lg border border-slate-100 text-slate-500 hover:bg-slate-50 disabled:opacity-40 disabled:hover:bg-transparent"
            >
              <ChevronRight className="h-4 w-4" />
            </button>
          </div>
        </div>
      )}
    </div>
  );
}
