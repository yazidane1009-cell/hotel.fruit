/**
 * @license
 * SPDX-License-Identifier: Apache-2.0
 */

import React, { useState } from 'react';
import { FruitType, LogType, LogEntry } from '../types';
import { PlusCircle, ShoppingBag, Trash2, Calendar, AlertCircle } from 'lucide-react';

interface FruitFormProps {
  fruits: FruitType[];
  inventory: Record<string, number>; // fruitId -> current quantity
  onLogSubmit: (log: Omit<LogEntry, 'id' | 'cost'> & { id?: string; cost?: number }) => void;
}

export default function FruitForm({ fruits, inventory, onLogSubmit }: FruitFormProps) {
  const [activeTab, setActiveTab] = useState<LogType>('supply');
  
  // Form fields state
  const [selectedFruitId, setSelectedFruitId] = useState<string>(fruits[0]?.id || '');
  const [quantity, setQuantity] = useState<number>(1);
  const [customCost, setCustomCost] = useState<string>(''); // For supply cost override if needed
  const [notes, setNotes] = useState<string>('');
  const [customDate, setCustomDate] = useState<string>(''); // empty means "now"

  // Feedback/validation states
  const [showSuccess, setShowSuccess] = useState(false);
  const [successMessage, setSuccessMessage] = useState('');

  // Selected Fruit Details
  const selectedFruit = fruits.find(f => f.id === selectedFruitId);
  const currentStock = inventory[selectedFruitId] || 0;

  // Handle fruit selection change (prefill cost for supply, etc.)
  const handleFruitChange = (id: string) => {
    setSelectedFruitId(id);
    const fruit = fruits.find(f => f.id === id);
    if (fruit) {
      setCustomCost(String(fruit.defaultCost));
    }
  };

  // Submit handler
  const handleSubmit = (e: React.FormEvent) => {
    e.preventDefault();
    if (!selectedFruit) return;

    if (quantity <= 0) {
      alert('請輸入大於 0 的數量');
      return;
    }

    const timestamp = customDate ? new Date(customDate).getTime() : Date.now();
    
    // For supply, cost can be custom overridden. For consume/waste, it's auto-derived from defaultCost
    const costValue = activeTab === 'supply' && customCost !== '' 
      ? Number(customCost) * quantity 
      : selectedFruit.defaultCost * quantity;

    onLogSubmit({
      timestamp,
      fruitId: selectedFruitId,
      type: activeTab,
      quantity,
      cost: costValue,
      notes: notes.trim() || undefined
    });

    // Show custom success Toast
    const actionText = activeTab === 'supply' 
      ? '補貨' 
      : activeTab === 'consumption' 
        ? '客人食用' 
        : '報廢';
    setSuccessMessage(`已成功記錄 1 筆 【${selectedFruit.name}】 ${actionText} ${quantity} ${selectedFruit.unit}！`);
    setShowSuccess(true);
    setTimeout(() => setShowSuccess(false), 3000);

    // Reset Form (except fruit selection for easy continuous entry)
    setQuantity(1);
    setNotes('');
    setCustomDate('');
  };

  const isStockInsufficient = activeTab !== 'supply' && quantity > currentStock;

  return (
    <div id="fruit_log_form_card" className="rounded-2xl border border-slate-100 bg-white p-6 shadow-sm">
      <div className="mb-5 flex flex-col justify-between gap-4 border-b border-slate-100 pb-4 sm:flex-row sm:items-center">
        <div>
          <h3 className="text-lg font-semibold text-slate-900">登記板</h3>
        </div>
        
        {/* Tab Buttons */}
        <div className="flex gap-1.5 rounded-xl bg-slate-100/80 p-1">
          <button
            id="tab_supply_btn"
            type="button"
            onClick={() => setActiveTab('supply')}
            className={`flex items-center gap-1.5 rounded-lg px-3.5 py-1.5 text-xs font-semibold transition-all ${
              activeTab === 'supply'
                ? 'bg-white text-emerald-600 shadow-sm'
                : 'text-slate-600 hover:text-slate-900'
            }`}
          >
            <PlusCircle className="h-4 w-4" />
            補貨上架
          </button>
          <button
            id="tab_consumption_btn"
            type="button"
            onClick={() => setActiveTab('consumption')}
            className={`flex items-center gap-1.5 rounded-lg px-3.5 py-1.5 text-xs font-semibold transition-all ${
              activeTab === 'consumption'
                ? 'bg-white text-indigo-600 shadow-sm'
                : 'text-slate-600 hover:text-slate-900'
            }`}
          >
            <ShoppingBag className="h-4 w-4" />
            客用統計
          </button>
          <button
            id="tab_wastage_btn"
            type="button"
            onClick={() => setActiveTab('wastage')}
            className={`flex items-center gap-1.5 rounded-lg px-3.5 py-1.5 text-xs font-semibold transition-all ${
              activeTab === 'wastage'
                ? 'bg-white text-rose-600 shadow-sm'
                : 'text-slate-600 hover:text-slate-900'
            }`}
          >
            <Trash2 className="h-4 w-4" />
            報廢清理
          </button>
        </div>
      </div>

      {showSuccess && (
        <div className="mb-4 flex items-center gap-2 rounded-xl bg-emerald-50 px-4 py-3 text-xs font-medium text-emerald-700 border border-emerald-100">
          <div className="h-1.5 w-1.5 rounded-full bg-emerald-500 animate-ping" />
          <span>{successMessage}</span>
        </div>
      )}

      <form onSubmit={handleSubmit} className="space-y-4">
        {/* Fruit selection & Stock display */}
        <div className="grid grid-cols-1 gap-4 sm:grid-cols-2">
          <div>
            <label className="block text-xs font-medium text-slate-700 mb-1.5">選擇水果項目</label>
            <select
              id="form_fruit_select"
              value={selectedFruitId}
              onChange={(e) => handleFruitChange(e.target.value)}
              className="w-full rounded-xl border border-slate-200 bg-slate-50/50 px-3.5 py-2.5 text-xs font-medium text-slate-800 transition focus:border-slate-300 focus:bg-white focus:outline-none focus:ring-2 focus:ring-slate-100"
            >
              {fruits.map(fruit => (
                <option key={fruit.id} value={fruit.id}>
                  {fruit.name}
                </option>
              ))}
            </select>
          </div>

          <div>
            <label className="block text-xs font-medium text-slate-700 mb-1.5">大廳現有庫存</label>
            <div className="flex h-[42px] items-center justify-between rounded-xl border border-slate-100 bg-slate-50/70 px-4">
              <span className="text-xs font-medium text-slate-500">
                目前擺放數量：
              </span>
              <span className={`text-sm font-bold ${currentStock > 0 ? 'text-emerald-600' : 'text-slate-400'}`}>
                {currentStock} {selectedFruit?.unit || '個'}
              </span>
            </div>
          </div>
        </div>

        {/* Quantity & Custom Cost */}
        <div className="grid grid-cols-1 gap-4 sm:grid-cols-2">
          <div>
            <label className="block text-xs font-medium text-slate-700 mb-1.5">
              輸入數量 ({selectedFruit?.unit})
            </label>
            <div className="flex items-center gap-2">
              <input
                id="form_quantity_input"
                type="number"
                min="1"
                step="any"
                value={quantity}
                onChange={(e) => setQuantity(Number(e.target.value))}
                className="w-full rounded-xl border border-slate-200 bg-slate-50/50 px-3.5 py-2.5 text-xs font-medium text-slate-800 transition focus:border-slate-300 focus:bg-white focus:outline-none focus:ring-2 focus:ring-slate-100"
                required
              />
              <div className="flex gap-1">
                <button
                  type="button"
                  onClick={() => setQuantity(prev => Math.max(1, prev - 1))}
                  className="flex h-[38px] w-[38px] items-center justify-center rounded-lg border border-slate-200 text-slate-600 hover:bg-slate-50 font-bold transition"
                >
                  -
                </button>
                <button
                  type="button"
                  onClick={() => setQuantity(prev => prev + 1)}
                  className="flex h-[38px] w-[38px] items-center justify-center rounded-lg border border-slate-200 text-slate-600 hover:bg-slate-50 font-bold transition"
                >
                  +
                </button>
              </div>
            </div>
          </div>

          {activeTab === 'supply' ? (
            <div>
              <label className="block text-xs font-medium text-slate-700 mb-1.5">
                單個估計成本 (TWD) <span className="text-[10px] text-slate-400 font-normal">(預設: ${selectedFruit?.defaultCost})</span>
              </label>
              <input
                id="form_cost_input"
                type="number"
                min="0"
                value={customCost}
                onChange={(e) => setCustomCost(e.target.value)}
                placeholder={String(selectedFruit?.defaultCost || 0)}
                className="w-full rounded-xl border border-slate-200 bg-slate-50/50 px-3.5 py-2.5 text-xs font-medium text-slate-800 transition focus:border-slate-300 focus:bg-white focus:outline-none focus:ring-2 focus:ring-slate-100"
              />
            </div>
          ) : activeTab === 'wastage' ? (
            <div>
              <label className="block text-xs font-medium text-slate-700 mb-1.5">單次記錄報廢損失</label>
              <div className="flex h-[42px] items-center justify-between rounded-xl border border-slate-100 bg-slate-50/70 px-4">
                <span className="text-xs font-medium text-slate-500">報廢累計金額：</span>
                <span className="text-xs font-bold text-rose-600">
                  ${(selectedFruit?.defaultCost || 0) * (quantity || 0)} TWD
                </span>
              </div>
            </div>
          ) : (
            <div>
              <label className="block text-xs font-medium text-slate-700 mb-1.5">單次記錄消耗成本</label>
              <div className="flex h-[42px] items-center justify-between rounded-xl border border-slate-100 bg-slate-50/70 px-4">
                <span className="text-xs font-medium text-slate-500">客用累計金額：</span>
                <span className="text-xs font-bold text-indigo-600">
                  ${(selectedFruit?.defaultCost || 0) * (quantity || 0)} TWD
                </span>
              </div>
            </div>
          )}
        </div>

        {/* DateTime override & Notes */}
        <div className="grid grid-cols-1 gap-4 sm:grid-cols-2">
          <div>
            <label className="block text-xs font-medium text-slate-700 mb-1.5 flex items-center gap-1">
              <Calendar className="h-3.5 w-3.5 text-slate-400" />
              補記日期時間 <span className="text-[10px] text-slate-400 font-normal">(留空代表現在)</span>
            </label>
            <input
              id="form_datetime_input"
              type="datetime-local"
              value={customDate}
              onChange={(e) => setCustomDate(e.target.value)}
              className="w-full rounded-xl border border-slate-200 bg-slate-50/50 px-3.5 py-2.5 text-xs font-medium text-slate-800 transition focus:border-slate-300 focus:bg-white focus:outline-none focus:ring-2 focus:ring-slate-100"
            />
          </div>

          <div>
            <label className="block text-xs font-medium text-slate-700 mb-1.5">備註說明 (選填)</label>
            <input
              id="form_notes_input"
              type="text"
              value={notes}
              onChange={(e) => setNotes(e.target.value)}
              placeholder="例如：擺放在大廳左側茶几、補加冰塊、夜班巡檢"
              className="w-full rounded-xl border border-slate-200 bg-slate-50/50 px-3.5 py-2.5 text-xs font-medium text-slate-800 transition focus:border-slate-300 focus:bg-white focus:outline-none focus:ring-2 focus:ring-slate-100"
            />
          </div>
        </div>

        {/* Stock status warnings */}
        {isStockInsufficient && (
          <div className="flex items-start gap-2.5 rounded-xl bg-amber-50 border border-amber-100 p-3.5 text-xs text-amber-800 animate-in fade-in duration-200">
            <AlertCircle className="h-4 w-4 text-amber-600 shrink-0 mt-0.5" />
            <div className="space-y-0.5">
              <p className="font-semibold">⚠️ 登記數量超過大廳現有庫存</p>
              <p className="text-slate-600">目前庫存僅剩 {currentStock} {selectedFruit?.unit}，若送出將導致該水果庫存變成負數。請確認您是否已完成了早先的「補貨上架」手續。</p>
            </div>
          </div>
        )}

        {/* Submit button */}
        <button
          id="form_submit_btn"
          type="submit"
          className={`w-full flex items-center justify-center gap-2 rounded-xl py-3 px-4 text-xs font-semibold text-white shadow-sm transition hover:shadow-md focus:outline-none focus:ring-2 focus:ring-offset-2 focus:ring-slate-400 cursor-pointer ${
            activeTab === 'supply'
              ? 'bg-emerald-600 hover:bg-emerald-700'
              : activeTab === 'consumption'
                ? 'bg-indigo-600 hover:bg-indigo-700'
                : 'bg-rose-600 hover:bg-rose-700'
          }`}
        >
          {activeTab === 'supply' && '確認補貨上架'}
          {activeTab === 'consumption' && '確認客人食用數量'}
          {activeTab === 'wastage' && '確認報廢清理數量'}
        </button>
      </form>
    </div>
  );
}
