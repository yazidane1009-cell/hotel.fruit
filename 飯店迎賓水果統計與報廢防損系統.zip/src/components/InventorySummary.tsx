/**
 * @license
 * SPDX-License-Identifier: Apache-2.0
 */

import React, { useState } from 'react';
import { FruitType, InventoryItem } from '../types';
import { formatCurrency } from '../utils';
import { Settings, Plus, Info, Edit3, Sliders, AlertTriangle } from 'lucide-react';
import { motion } from 'motion/react';

interface InventorySummaryProps {
  fruits: FruitType[];
  inventory: Record<string, number>; // fruitId -> current quantity
  totals: Record<string, InventoryItem>; // fruitId -> full totals
  onAddFruit: (fruit: Omit<FruitType, 'id'> & { id: string }) => void;
  onUpdateFruitPrice: (id: string, newCost: number) => void;
}

export default function InventorySummary({
  fruits,
  inventory,
  totals,
  onAddFruit,
  onUpdateFruitPrice,
}: InventorySummaryProps) {
  const [showSettings, setShowSettings] = useState(false);
  
  // New Fruit Form state
  const [newFruitName, setNewFruitName] = useState('');
  const [newFruitUnit, setNewFruitUnit] = useState('個');
  const [newFruitCost, setNewFruitCost] = useState(20);
  const [newFruitColor, setNewFruitColor] = useState('#ec4899'); // pink-500 default

  // Price adjustment state
  const [editingFruitId, setEditingFruitId] = useState<string | null>(null);
  const [tempPrice, setTempPrice] = useState<number>(0);

  // Submit new fruit
  const handleAddFruitSubmit = (e: React.FormEvent) => {
    e.preventDefault();
    if (!newFruitName.trim()) return;

    // Create a URL-safe lowercase ID
    const generatedId = 'custom_' + newFruitName.trim().toLowerCase().replace(/\s+/g, '_');
    
    // Check duplication
    if (fruits.some(f => f.id === generatedId || f.name.toLowerCase() === newFruitName.toLowerCase())) {
      alert('該水果品項已存在！');
      return;
    }

    onAddFruit({
      id: generatedId,
      name: newFruitName.trim(),
      unit: newFruitUnit,
      defaultCost: Number(newFruitCost),
      color: newFruitColor
    });

    // Reset Form
    setNewFruitName('');
    setNewFruitUnit('個');
    setNewFruitCost(20);
    setNewFruitColor('#ec4899');
  };

  const startEditingPrice = (fruit: FruitType) => {
    setEditingFruitId(fruit.id);
    setTempPrice(fruit.defaultCost);
  };

  const savePriceEdit = (id: string) => {
    onUpdateFruitPrice(id, tempPrice);
    setEditingFruitId(null);
  };

  return (
    <div id="lobby_inventory_summary_section" className="space-y-6">
      {/* 1. Real-time Inventory Cards */}
      <div className="rounded-2xl border border-slate-100 bg-white p-6 shadow-sm">
        <div className="mb-5 flex items-center justify-between">
          <div>
            <h3 className="text-lg font-semibold text-slate-900">水果現況</h3>
          </div>

          <button
            id="toggle_fruit_settings_btn"
            onClick={() => setShowSettings(!showSettings)}
            className={`flex items-center gap-1.5 rounded-xl border px-3.5 py-1.5 text-xs font-semibold transition ${
              showSettings 
                ? 'bg-slate-900 text-white border-slate-900' 
                : 'bg-white text-slate-600 border-slate-200 hover:bg-slate-50'
            } cursor-pointer`}
          >
            <Sliders className="h-3.5 w-3.5" />
            {showSettings ? '關閉管理面板' : '管理水果與定價'}
          </button>
        </div>

        {/* Inventory Cards Grid */}
        <div className="grid grid-cols-2 gap-4 md:grid-cols-3 xl:grid-cols-6">
          {fruits.map((fruit) => {
            const currentQty = inventory[fruit.id] || 0;
            const itemTotals = totals[fruit.id] || { totalSupplied: 0, totalConsumed: 0, totalWasted: 0 };
            
            // Calculate a replenishment index
            const isOutOfStock = currentQty <= 0;
            const isLowStock = currentQty > 0 && currentQty < 5;
            
            // Percentage of consumption out of what was supplied
            const consumptionPercent = itemTotals.totalSupplied > 0 
              ? Math.round((itemTotals.totalConsumed / itemTotals.totalSupplied) * 100) 
              : 0;

            return (
              <div
                key={fruit.id}
                className={`relative overflow-hidden rounded-xl border p-4 transition-all hover:shadow-sm ${
                  isOutOfStock 
                    ? 'border-rose-100 bg-rose-50/10' 
                    : isLowStock 
                      ? 'border-amber-100 bg-amber-50/10' 
                      : 'border-slate-100 bg-white'
                }`}
              >
                {/* Colored Top bar decoration */}
                <div className="absolute top-0 left-0 right-0 h-1" style={{ backgroundColor: fruit.color }} />
                
                <div className="flex flex-col h-full justify-between space-y-3.5">
                  <div>
                    <div className="flex items-start justify-between">
                      <span className="text-xs font-bold text-slate-800 line-clamp-1">{fruit.name.split(' ')[0]}</span>
                      <span className="text-[10px] text-slate-400 font-medium">({fruit.unit})</span>
                    </div>
                    
                    {/* Main Stock Number */}
                    <div className="mt-2.5 flex items-baseline gap-1">
                      <span className={`text-2xl font-black ${isOutOfStock ? 'text-rose-500' : 'text-slate-900'}`}>
                        {currentQty}
                      </span>
                    </div>
                  </div>

                  {/* Stock Alert Badge */}
                  <div>
                    {isOutOfStock ? (
                      <span className="inline-flex w-full items-center justify-center rounded-lg bg-rose-50 text-[10px] font-bold text-rose-700 py-1 border border-rose-100">
                        ⚠️ 盤已空需補貨
                      </span>
                    ) : isLowStock ? (
                      <span className="inline-flex w-full items-center justify-center rounded-lg bg-amber-50 text-[10px] font-bold text-amber-700 py-1 border border-amber-100">
                        ⚠️ 存量偏低
                      </span>
                    ) : (
                      <span className="inline-flex w-full items-center justify-center rounded-lg bg-emerald-50 text-[10px] font-bold text-emerald-700 py-1 border border-emerald-100">
                        ✓ 存量充足
                      </span>
                    )}
                  </div>

                  {/* Micro Usage Progress Bar */}
                  <div className="space-y-1 pt-1 border-t border-slate-50">
                    <div className="flex justify-between text-[9px] text-slate-400 font-medium">
                      <span>累計食用比</span>
                      <span>{consumptionPercent}%</span>
                    </div>
                    <div className="h-1 w-full rounded-full bg-slate-100 overflow-hidden">
                      <div 
                        className="h-full rounded-full transition-all duration-300" 
                        style={{ width: `${Math.min(consumptionPercent, 100)}%`, backgroundColor: fruit.color }}
                      />
                    </div>
                  </div>
                </div>
              </div>
            );
          })}
        </div>
      </div>

      {/* 2. Settings management panel (Animate Open) */}
      {showSettings && (
        <div id="fruit_settings_panel" className="grid grid-cols-1 gap-6 md:grid-cols-3 animate-in fade-in slide-in-from-top-4 duration-300">
          
          {/* A. Unit Price Settings Table (2/3 Width) */}
          <div className="rounded-2xl border border-slate-100 bg-white p-6 shadow-sm md:col-span-2">
            <h4 className="flex items-center gap-2 text-sm font-bold text-slate-800 mb-1.5">
              <Sliders className="h-4 w-4 text-slate-500" />
              水果成本價格與品項清單
            </h4>
            <p className="text-xs text-slate-400 mb-4">設定預設的採購單價，以便自動計算大廳的食材總開銷與報廢浪費金額</p>
            
            <div className="overflow-hidden rounded-xl border border-slate-100">
              <table className="w-full text-left text-xs">
                <thead>
                  <tr className="border-b border-slate-100 bg-slate-50/70 text-slate-500 font-semibold">
                    <th className="p-3">水果項目</th>
                    <th className="p-3">計量單位</th>
                    <th className="p-3">預設單價 (TWD)</th>
                    <th className="p-3">色碼標籤</th>
                    <th className="p-3 text-center">修改單價</th>
                  </tr>
                </thead>
                <tbody className="divide-y divide-slate-50 text-slate-600">
                  {fruits.map((fruit) => (
                    <tr key={fruit.id} className="hover:bg-slate-50/50">
                      <td className="p-3 font-semibold text-slate-800 flex items-center gap-2">
                        <span className="h-2 w-2 rounded-full" style={{ backgroundColor: fruit.color }} />
                        {fruit.name}
                      </td>
                      <td className="p-3 font-medium">{fruit.unit}</td>
                      <td className="p-3 font-bold">
                        {editingFruitId === fruit.id ? (
                          <input
                            type="number"
                            value={tempPrice}
                            onChange={(e) => setTempPrice(Number(e.target.value))}
                            className="w-20 rounded-md border border-slate-300 px-2 py-1 text-xs"
                          />
                        ) : (
                          formatCurrency(fruit.defaultCost)
                        )}
                      </td>
                      <td className="p-3">
                        <span className="font-mono text-[10px] text-slate-400">{fruit.color}</span>
                      </td>
                      <td className="p-3 text-center">
                        {editingFruitId === fruit.id ? (
                          <div className="flex justify-center gap-1.5">
                            <button
                              onClick={() => savePriceEdit(fruit.id)}
                              className="rounded bg-emerald-500 px-2 py-1 text-[10px] font-bold text-white hover:bg-emerald-600"
                            >
                              儲存
                            </button>
                            <button
                              onClick={() => setEditingFruitId(null)}
                              className="rounded bg-slate-200 px-2 py-1 text-[10px] font-bold text-slate-600 hover:bg-slate-300"
                            >
                              取消
                            </button>
                          </div>
                        ) : (
                          <button
                            onClick={() => startEditingPrice(fruit)}
                            className="inline-flex items-center gap-1 rounded bg-slate-100 hover:bg-slate-200 text-slate-700 px-2.5 py-1 text-[10px] font-semibold cursor-pointer"
                          >
                            <Edit3 className="h-3 w-3" />
                            修改
                          </button>
                        )}
                      </td>
                    </tr>
                  ))}
                </tbody>
              </table>
            </div>
          </div>

          {/* B. Add New Fruit Variety (1/3 Width) */}
          <div className="rounded-2xl border border-slate-100 bg-white p-6 shadow-sm">
            <h4 className="flex items-center gap-2 text-sm font-bold text-slate-800 mb-1.5">
              <Plus className="h-4.5 w-4.5 text-emerald-500" />
              新增迎賓水果品項
            </h4>
            <p className="text-xs text-slate-400 mb-4">若飯店引進了新種類的迎賓水果，可在此新增</p>

            <form onSubmit={handleAddFruitSubmit} className="space-y-4">
              <div>
                <label className="block text-xs font-semibold text-slate-700 mb-1">水果名稱</label>
                <input
                  id="new_fruit_name"
                  type="text"
                  placeholder="例如：芭樂 (Guava)"
                  value={newFruitName}
                  onChange={(e) => setNewFruitName(e.target.value)}
                  className="w-full rounded-xl border border-slate-200 bg-slate-50/50 px-3.5 py-2.5 text-xs font-medium text-slate-800 transition focus:border-slate-300 focus:bg-white focus:outline-none"
                  required
                />
              </div>

              <div className="grid grid-cols-2 gap-3">
                <div>
                  <label className="block text-xs font-semibold text-slate-700 mb-1">計量單位</label>
                  <input
                    id="new_fruit_unit"
                    type="text"
                    placeholder="例如：個、根、串"
                    value={newFruitUnit}
                    onChange={(e) => setNewFruitUnit(e.target.value)}
                    className="w-full rounded-xl border border-slate-200 bg-slate-50/50 px-3.5 py-2.5 text-xs font-medium text-slate-800 transition focus:border-slate-300 focus:bg-white focus:outline-none"
                    required
                  />
                </div>

                <div>
                  <label className="block text-xs font-semibold text-slate-700 mb-1">採購單價 (TWD)</label>
                  <input
                    id="new_fruit_cost"
                    type="number"
                    min="1"
                    value={newFruitCost}
                    onChange={(e) => setNewFruitCost(Number(e.target.value))}
                    className="w-full rounded-xl border border-slate-200 bg-slate-50/50 px-3.5 py-2.5 text-xs font-medium text-slate-800 transition focus:border-slate-300 focus:bg-white focus:outline-none"
                    required
                  />
                </div>
              </div>

              <div>
                <label className="block text-xs font-semibold text-slate-700 mb-1">圖表辨識色</label>
                <div className="flex items-center gap-2">
                  <input
                    id="new_fruit_color"
                    type="color"
                    value={newFruitColor}
                    onChange={(e) => setNewFruitColor(e.target.value)}
                    className="h-[38px] w-12 rounded-lg border border-slate-200 cursor-pointer p-0.5"
                  />
                  <span className="font-mono text-xs text-slate-500 uppercase">{newFruitColor}</span>
                </div>
              </div>

              <button
                id="add_new_fruit_btn"
                type="submit"
                className="w-full flex items-center justify-center gap-1.5 rounded-xl bg-emerald-600 hover:bg-emerald-700 py-2.5 px-4 text-xs font-semibold text-white shadow-sm transition hover:shadow-md cursor-pointer"
              >
                <Plus className="h-4 w-4" />
                新增此水果品項
              </button>
            </form>
          </div>

        </div>
      )}
    </div>
  );
}
