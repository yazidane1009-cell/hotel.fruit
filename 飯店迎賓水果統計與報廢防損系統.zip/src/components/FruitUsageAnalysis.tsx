/**
 * @license
 * SPDX-License-Identifier: Apache-2.0
 */

import React, { useMemo, useState } from 'react';
import { LogEntry, FruitType } from '../types';
import { formatCurrency } from '../utils';
import {
  BarChart,
  Bar,
  XAxis,
  YAxis,
  CartesianGrid,
  Tooltip,
  Legend,
  ResponsiveContainer,
} from 'recharts';
import {
  AlertTriangle,
  ThumbsUp,
  Award,
  Activity,
  Lightbulb,
  Sparkles,
  Layers,
  CheckCircle2,
} from 'lucide-react';
import { motion } from 'motion/react';

interface FruitUsageAnalysisProps {
  logs: LogEntry[];
  fruits: FruitType[];
}

export default function FruitUsageAnalysis({ logs, fruits }: FruitUsageAnalysisProps) {
  const [analysisSubTab, setAnalysisSubTab] = useState<'leaderboard' | 'purchaseAdvice'>('leaderboard');

  const oldestLogDateStr = useMemo(() => {
    if (logs.length === 0) return new Date().toISOString().split('T')[0];
    const timestamps = logs.map(l => new Date(l.timestamp).getTime());
    const minTimestamp = Math.min(...timestamps);
    return new Date(minTimestamp).toISOString().split('T')[0];
  }, [logs]);

  const [startDateStr, setStartDateStr] = useState<string>(() => {
    const d = new Date();
    d.setDate(d.getDate() - 29); // Past 30 days by default
    return d.toISOString().split('T')[0];
  });
  const [endDateStr, setEndDateStr] = useState<string>(() => {
    return new Date().toISOString().split('T')[0];
  });

  const activeQuickRange = useMemo(() => {
    const start = new Date(startDateStr);
    const end = new Date(endDateStr);
    start.setHours(0, 0, 0, 0);
    end.setHours(0, 0, 0, 0);
    
    // Check if matches 'all'
    if (startDateStr === oldestLogDateStr) {
      const todayStr = new Date().toISOString().split('T')[0];
      if (endDateStr === todayStr) {
        return 'all';
      }
    }
    
    const diffTime = Math.abs(end.getTime() - start.getTime());
    const diffDays = Math.ceil(diffTime / (1000 * 60 * 60 * 24));
    
    const todayStr = new Date().toISOString().split('T')[0];
    if (endDateStr === todayStr) {
      if (diffDays === 7) return 7;
      if (diffDays === 14) return 14;
      if (diffDays === 30) return 30;
    }
    return null;
  }, [startDateStr, endDateStr, oldestLogDateStr]);

  const handleSetQuickRange = (days: number | 'all') => {
    const end = new Date();
    const endDateStr = end.toISOString().split('T')[0];
    setEndDateStr(endDateStr);
    
    if (days === 'all') {
      setStartDateStr(oldestLogDateStr);
    } else {
      const start = new Date();
      start.setDate(end.getDate() - (days - 1));
      setStartDateStr(start.toISOString().split('T')[0]);
    }
  };

  const filteredLogs = useMemo(() => {
    const start = new Date(startDateStr);
    start.setHours(0, 0, 0, 0);
    const end = new Date(endDateStr);
    end.setHours(23, 59, 59, 999);

    const actualStart = start <= end ? start : end;
    const actualEnd = start <= end ? end : start;

    return logs.filter(log => {
      const d = new Date(log.timestamp);
      return d >= actualStart && d <= actualEnd;
    });
  }, [logs, startDateStr, endDateStr]);

  const fruitMap = useMemo(() => new Map(fruits.map(f => [f.id, f])), [fruits]);

  // --- 1. Fruit Metrics Calculation ---
  const fruitRankings = useMemo(() => {
    const stats: Record<string, {
      id: string;
      name: string;
      color: string;
      unit: string;
      supplyQty: number;
      supplyCost: number;
      consumeQty: number;
      consumeCost: number;
      wasteQty: number;
      wasteCost: number;
    }> = {};

    fruits.forEach(f => {
      stats[f.id] = {
        id: f.id,
        name: f.name,
        color: f.color,
        unit: f.unit,
        supplyQty: 0,
        supplyCost: 0,
        consumeQty: 0,
        consumeCost: 0,
        wasteQty: 0,
        wasteCost: 0,
      };
    });

    filteredLogs.forEach(log => {
      if (!stats[log.fruitId]) {
        const fruit = fruitMap.get(log.fruitId);
        stats[log.fruitId] = {
          id: log.fruitId,
          name: fruit ? fruit.name : '自訂水果',
          color: fruit ? fruit.color : '#94a3b8',
          unit: fruit ? fruit.unit : '個',
          supplyQty: 0,
          supplyCost: 0,
          consumeQty: 0,
          consumeCost: 0,
          wasteQty: 0,
          wasteCost: 0,
        };
      }

      const fStat = stats[log.fruitId];
      if (log.type === 'supply') {
        fStat.supplyQty += log.quantity;
        fStat.supplyCost += log.cost;
      } else if (log.type === 'consumption') {
        fStat.consumeQty += log.quantity;
        fStat.consumeCost += log.cost;
      } else if (log.type === 'wastage') {
        fStat.wasteQty += log.quantity;
        fStat.wasteCost += log.cost;
      }
    });

    return Object.values(stats).map(f => {
      const wasteRate = f.supplyQty > 0 ? (f.wasteQty / f.supplyQty) * 100 : 0;
      const consumeRate = f.supplyQty > 0 ? (f.consumeQty / f.supplyQty) * 100 : 0;
      return {
        ...f,
        wasteRate,
        consumeRate,
      };
    }).sort((a, b) => b.consumeQty - a.consumeQty); // Sorted by consumption popularity
  }, [filteredLogs, fruits, fruitMap]);

  // --- 2. Smart Purchase & Safety Stock Levels (No hourly/reason dependencies) ---
  const purchaseAdviceData = useMemo(() => {
    // Determine the number of unique days in the logs to compute daily averages
    const uniqueDays = new Set<string>();
    filteredLogs.forEach(log => {
      const d = new Date(log.timestamp);
      const dayKey = `${d.getFullYear()}-${d.getMonth() + 1}-${d.getDate()}`;
      uniqueDays.add(dayKey);
    });
    
    // Fallback to 1 if no logs
    const totalDays = Math.max(1, uniqueDays.size);

    return fruits.map(f => {
      const ranking = fruitRankings.find(r => r.id === f.id) || {
        supplyQty: 0,
        consumeQty: 0,
        wasteQty: 0,
        supplyCost: 0,
        consumeCost: 0,
        wasteCost: 0,
        wasteRate: 0,
        consumeRate: 0,
      };

      const avgDailyConsume = ranking.consumeQty / totalDays;
      const avgDailyWaste = ranking.wasteQty / totalDays;
      
      // Safety Stock: 1.5 times daily consumption, minimum of 3
      const safetyStock = Math.max(3, Math.ceil(avgDailyConsume * 1.5));
      
      let status = '補貨水位合適';
      let statusStyle = 'text-emerald-700 bg-emerald-50 border-emerald-100';
      let adviceText = '目前大廳消耗與報廢極為平衡，請維持目前的日常清點與上架步調。';

      if (ranking.supplyQty > 0) {
        if (ranking.wasteRate > 25) {
          status = '防損：建議減少陳列數量';
          statusStyle = 'text-rose-700 bg-rose-50 border-rose-100';
          adviceText = `此品項累計報廢比率達 ${ranking.wasteRate.toFixed(0)}%。在大廳滯留時間長易熟化。建議調低陳列基準線至每日 ${safetyStock} ${f.unit}。維持「少量多次」擺盤，可有效消滅不必要報廢。`;
        } else if (ranking.consumeRate > 80) {
          status = '熱銷：建議優先增加陳列';
          statusStyle = 'text-indigo-700 bg-indigo-50 border-indigo-100';
          adviceText = `旅客最愛！高達 ${ranking.consumeRate.toFixed(0)}% 的水果皆被高興食用。建議大廳每日擺放安全庫存 ${safetyStock} ${f.unit} 以上，確保入住尖峰不缺貨，提升迎賓好評。`;
        } else if (ranking.supplyQty > 5 && ranking.consumeQty === 0) {
          status = '警告：本期零客用全報廢';
          statusStyle = 'text-amber-700 bg-amber-50 border-amber-100';
          adviceText = '有補貨記錄卻 100% 報廢，客人無人取用。旅客可能對此水果不感興趣，強烈建議減少或暫停採購，改換成蘋果或香蕉等熱銷品項。';
        }
      } else {
        status = '尚無本期流動數據';
        statusStyle = 'text-slate-500 bg-slate-50 border-slate-100';
        adviceText = '在選取的會計流水帳中，該品項尚無補貨上架或食用數據。';
      }

      return {
        ...f,
        avgDailyConsume,
        avgDailyWaste,
        safetyStock,
        status,
        statusStyle,
        adviceText,
        wasteRate: ranking.wasteRate,
        consumeRate: ranking.consumeRate,
      };
    });
  }, [filteredLogs, fruits, fruitRankings]);

  // Overall statistics
  const overallStats = useMemo(() => {
    let totalSupplied = 0;
    let totalConsumed = 0;
    let totalWasted = 0;
    let totalWastedCost = 0;

    fruitRankings.forEach(f => {
      totalSupplied += f.supplyQty;
      totalConsumed += f.consumeQty;
      totalWasted += f.wasteQty;
      totalWastedCost += f.wasteCost;
    });

    const consumeRate = totalSupplied > 0 ? (totalConsumed / totalSupplied) * 100 : 0;
    const wasteRate = totalSupplied > 0 ? (totalWasted / totalSupplied) * 100 : 0;

    return {
      totalSupplied,
      totalConsumed,
      totalWasted,
      totalWastedCost,
      consumeRate,
      wasteRate,
    };
  }, [fruitRankings]);

  return (
    <div id="fruit_usage_analytics_section" className="space-y-6">
      
      {/* 1. Header Card with General Stats */}
      <div className="rounded-2xl border border-slate-100 bg-gradient-to-r from-emerald-500/10 via-teal-500/5 to-white p-6 shadow-xs">
        <div className="flex flex-col justify-between gap-4 md:flex-row md:items-center">
          <div>
            <h3 className="flex items-center gap-2 text-md font-extrabold text-slate-900">
              <Activity className="h-5 w-5 text-emerald-600 animate-pulse" />
              迎賓水果耗用與採購分析
            </h3>
          </div>

          {/* Quick Stats Summary Pills */}
          <div className="flex flex-wrap gap-2">
            <div className="rounded-lg bg-white px-3 py-1.5 border border-slate-100 shadow-2xs flex items-center gap-2">
              <ThumbsUp className="h-3.5 w-3.5 text-indigo-500" />
              <div className="text-[10px]">
                <span className="text-slate-400 block font-semibold">客用招待率</span>
                <span className="font-extrabold text-indigo-600 text-xs">
                  {overallStats.consumeRate.toFixed(1)}%
                </span>
              </div>
            </div>

            <div className="rounded-lg bg-white px-3 py-1.5 border border-slate-100 shadow-2xs flex items-center gap-2">
              <AlertTriangle className="h-3.5 w-3.5 text-rose-500" />
              <div className="text-[10px]">
                <span className="text-slate-400 block font-semibold">總報廢損耗率</span>
                <span className="font-extrabold text-rose-600 text-xs">
                  {overallStats.wasteRate.toFixed(1)}%
                </span>
              </div>
            </div>
          </div>
        </div>

        {/* Date Filter Bar */}
        <div className="mt-4 flex flex-wrap items-center gap-3 border-t border-slate-100/50 pt-4">
          {/* Quick Presets */}
          <div className="flex items-center gap-1.5">
            <span className="text-[11px] font-bold text-slate-400">分析區間：</span>
            <div className="flex rounded-lg bg-white/80 p-0.5 border border-slate-100 shadow-2xs">
              <button
                id="analysis_range_7d_btn"
                onClick={() => handleSetQuickRange(7)}
                className={`rounded-md px-2.5 py-1 text-[11px] font-semibold transition cursor-pointer ${
                  activeQuickRange === 7 ? 'bg-emerald-500 text-white shadow-xs' : 'text-slate-500 hover:text-slate-900'
                }`}
              >
                7 天
              </button>
              <button
                id="analysis_range_14d_btn"
                onClick={() => handleSetQuickRange(14)}
                className={`rounded-md px-2.5 py-1 text-[11px] font-semibold transition cursor-pointer ${
                  activeQuickRange === 14 ? 'bg-emerald-500 text-white shadow-xs' : 'text-slate-500 hover:text-slate-900'
                }`}
              >
                14 天
              </button>
              <button
                id="analysis_range_30d_btn"
                onClick={() => handleSetQuickRange(30)}
                className={`rounded-md px-2.5 py-1 text-[11px] font-semibold transition cursor-pointer ${
                  activeQuickRange === 30 ? 'bg-emerald-500 text-white shadow-xs' : 'text-slate-500 hover:text-slate-900'
                }`}
              >
                30 天
              </button>
              <button
                id="analysis_range_all_btn"
                onClick={() => handleSetQuickRange('all')}
                className={`rounded-md px-2.5 py-1 text-[11px] font-semibold transition cursor-pointer ${
                  activeQuickRange === 'all' ? 'bg-emerald-500 text-white shadow-xs' : 'text-slate-500 hover:text-slate-900'
                }`}
              >
                全部
              </button>
            </div>
          </div>

          {/* Custom Date Range Picker */}
          <div className="flex items-center gap-1.5 rounded-lg border border-slate-100 bg-white/80 px-2.5 py-1 shadow-2xs">
            <input
              id="analysis_start_date"
              type="date"
              value={startDateStr}
              onChange={(e) => setStartDateStr(e.target.value)}
              className="bg-transparent text-[11px] font-bold text-slate-700 focus:outline-none cursor-pointer"
            />
            <span className="text-[10px] text-slate-400 font-bold">至</span>
            <input
              id="analysis_end_date"
              type="date"
              value={endDateStr}
              onChange={(e) => setEndDateStr(e.target.value)}
              className="bg-transparent text-[11px] font-bold text-slate-700 focus:outline-none cursor-pointer"
            />
          </div>
        </div>

        {/* Inner sub-tabs */}
        <div className="flex gap-1.5 mt-6 border-b border-slate-100 pb-0.5">
          <button
            id="subtab_leaderboard"
            onClick={() => setAnalysisSubTab('leaderboard')}
            className={`pb-2.5 px-4 text-xs font-bold transition-all relative cursor-pointer ${
              analysisSubTab === 'leaderboard'
                ? 'text-emerald-600 font-extrabold'
                : 'text-slate-400 hover:text-slate-600'
            }`}
          >
            {analysisSubTab === 'leaderboard' && (
              <motion.div layoutId="subtab_bar" className="absolute bottom-0 left-0 right-0 h-0.5 bg-emerald-500" />
            )}
            <span className="flex items-center gap-1.5">
              <Award className="h-3.5 w-3.5" />
              水果耗用排行 (Rankings)
            </span>
          </button>

          <button
            id="subtab_purchase_advice"
            onClick={() => setAnalysisSubTab('purchaseAdvice')}
            className={`pb-2.5 px-4 text-xs font-bold transition-all relative cursor-pointer ${
              analysisSubTab === 'purchaseAdvice'
                ? 'text-emerald-600 font-extrabold'
                : 'text-slate-400 hover:text-slate-600'
            }`}
          >
            {analysisSubTab === 'purchaseAdvice' && (
              <motion.div layoutId="subtab_bar" className="absolute bottom-0 left-0 right-0 h-0.5 bg-emerald-500" />
            )}
            <span className="flex items-center gap-1.5">
              <Lightbulb className="h-3.5 w-3.5" />
              營運與採購分析
            </span>
          </button>
        </div>
      </div>

      {/* 2. Sub-tab Contents */}
      <div className="grid grid-cols-1 gap-6">

        {/* Tab A: Leaderboard */}
        {analysisSubTab === 'leaderboard' && (
          <div className="space-y-6">
            
            {/* Horizontal comparison chart */}
            <div className="rounded-2xl border border-slate-100 bg-white p-6 shadow-sm">
              <h4 className="text-sm font-extrabold text-slate-800 mb-4 flex items-center gap-1.5">
                <Layers className="h-4 w-4 text-emerald-500" />
                各類迎賓水果「客用價值」與「報廢損失」交叉對比圖
              </h4>
              <div className="h-[280px] w-full">
                <ResponsiveContainer width="100%" height="100%">
                  <BarChart
                    data={fruitRankings}
                    layout="vertical"
                    margin={{ top: 10, right: 20, left: 10, bottom: 5 }}
                  >
                    <CartesianGrid strokeDasharray="3 3" horizontal={true} stroke="#f1f5f9" />
                    <XAxis type="number" tickLine={false} axisLine={false} tick={{ fontSize: 10, fill: '#64748b' }} tickFormatter={(v) => `$${v}`} />
                    <YAxis dataKey="name" type="category" tickLine={false} axisLine={false} tick={{ fontSize: 10, fill: '#1e293b', fontWeight: 600 }} width={100} />
                    <Tooltip
                      contentStyle={{ borderRadius: '12px', border: '1px solid #f1f5f9', fontSize: '11px' }}
                      formatter={(v) => [formatCurrency(Number(v)), '']}
                    />
                    <Legend wrapperStyle={{ fontSize: '11px', fontWeight: 600 }} />
                    <Bar dataKey="consumeCost" name="顧客食用總值" fill="#6366f1" radius={[0, 4, 4, 0]} />
                    <Bar dataKey="wasteCost" name="食材報廢損失" fill="#ef4444" radius={[0, 4, 4, 0]} />
                  </BarChart>
                </ResponsiveContainer>
              </div>
            </div>

            {/* Performance Ranking Cards */}
            <div className="grid grid-cols-1 gap-4 md:grid-cols-2 lg:grid-cols-3">
              {fruitRankings.map((f, idx) => {
                const isHighlyWasted = f.wasteRate > 15;
                return (
                  <div
                    key={f.id}
                    className="relative overflow-hidden rounded-2xl border border-slate-100 bg-white p-5 shadow-2xs transition-all hover:shadow-xs hover:border-slate-200"
                  >
                    {/* Corner rank number */}
                    <span className="absolute right-4 top-4 text-3xl font-black text-slate-100/70 select-none">
                      #{idx + 1}
                    </span>

                    <div className="flex items-center gap-2.5 mb-3.5">
                      <span className="h-3 w-3 rounded-full shrink-0 animate-pulse" style={{ backgroundColor: f.color }} />
                      <h5 className="font-extrabold text-slate-900 text-sm">{f.name}</h5>
                    </div>

                    {/* Progress bars */}
                    <div className="space-y-3.5 text-xs">
                      {/* Consumption */}
                      <div>
                        <div className="flex justify-between text-slate-500 mb-1">
                          <span>顧客食用量</span>
                          <span className="font-bold text-indigo-600">
                            {f.consumeQty} {f.unit} ({f.consumeRate.toFixed(1)}%)
                          </span>
                        </div>
                        <div className="h-2 w-full bg-slate-100 rounded-full overflow-hidden">
                          <div
                            className="h-full bg-indigo-500 rounded-full transition-all duration-500"
                            style={{ width: `${Math.min(100, f.consumeRate)}%` }}
                          />
                        </div>
                      </div>

                      {/* Wastage */}
                      <div>
                        <div className="flex justify-between text-slate-500 mb-1">
                          <span>報廢損耗量</span>
                          <span className={`font-bold ${isHighlyWasted ? 'text-rose-600' : 'text-slate-700'}`}>
                            {f.wasteQty} {f.unit} ({f.wasteRate.toFixed(1)}%)
                          </span>
                        </div>
                        <div className="h-2 w-full bg-slate-100 rounded-full overflow-hidden">
                          <div
                            className={`h-full rounded-full transition-all duration-500 ${
                              isHighlyWasted ? 'bg-rose-500 animate-pulse' : 'bg-slate-400'
                            }`}
                            style={{ width: `${Math.min(100, f.wasteRate)}%` }}
                          />
                        </div>
                      </div>

                      {/* Financial Detail Summary */}
                      <div className="pt-3 border-t border-slate-100 grid grid-cols-2 gap-2 text-[10px] font-semibold text-slate-500">
                        <div>
                          <span>食用價值:</span>
                          <span className="block text-indigo-600 text-xs font-extrabold mt-0.5">
                            {formatCurrency(f.consumeCost)}
                          </span>
                        </div>
                        <div>
                          <span>報廢損失:</span>
                          <span className={`block text-xs font-extrabold mt-0.5 ${f.wasteCost > 0 ? 'text-rose-600' : 'text-slate-600'}`}>
                            {formatCurrency(f.wasteCost)}
                          </span>
                        </div>
                      </div>
                    </div>

                    {/* Highly Wasted Warning Badge */}
                    {isHighlyWasted && (
                      <div className="mt-4 rounded-xl bg-amber-50 border border-amber-100 p-2.5 flex items-start gap-1.5 text-[10px] text-amber-800">
                        <AlertTriangle className="h-4 w-4 text-amber-600 shrink-0 mt-0.5" />
                        <div>
                          <span className="font-bold block">損耗偏高警示！</span>
                          <span>該水果損耗比率超過 15% 門檻，陳列滯留率高，建議調降常規備量，並按「智慧採購與防損建議」設定大廳陳列水位。</span>
                        </div>
                      </div>
                    )}
                  </div>
                );
              })}
            </div>
          </div>
        )}

        {/* Tab B: Smart Purchase & Safety Stock Levels */}
        {analysisSubTab === 'purchaseAdvice' && (
          <div className="space-y-6">
            
            {/* Purchase Advice Grid Header */}
            <div className="rounded-2xl border border-indigo-100 bg-indigo-50/20 p-5 shadow-xs flex flex-col md:flex-row gap-4 justify-between items-start md:items-center">
              <div className="space-y-1">
                <span className="text-xs font-extrabold text-indigo-700 tracking-wider uppercase flex items-center gap-1.5">
                  <Sparkles className="h-4 w-4 text-indigo-500 animate-spin-slow" />
                  數據演算：迎賓水果「防損控制水位與採購安全係數」
                </span>
                <p className="text-xs text-slate-500">
                  系統根據本期內「日均消耗量」與「報廢比例」模型，自動為各水果品項計算出防損安全陳列量與針對性的補採購策略。
                </p>
              </div>
              
              <div className="rounded-xl bg-white px-4 py-3 border border-indigo-100/50 text-xs">
                <span className="text-slate-400 font-medium block">本期食材報廢累積損失</span>
                <span className="text-lg font-black text-rose-600">{formatCurrency(overallStats.totalWastedCost)}</span>
              </div>
            </div>

            {/* Advice Cards Grid */}
            <div className="grid grid-cols-1 gap-6 lg:grid-cols-2">
              {purchaseAdviceData.map(advice => (
                <div
                  key={advice.id}
                  className="rounded-2xl border border-slate-100 bg-white p-6 shadow-sm flex flex-col justify-between hover:border-slate-200 transition"
                >
                  <div>
                    {/* Top status & Fruit info */}
                    <div className="flex justify-between items-start gap-3 mb-4">
                      <div className="flex items-center gap-2">
                        <span className="h-3.5 w-3.5 rounded-full shrink-0" style={{ backgroundColor: advice.color }} />
                        <h4 className="text-sm font-extrabold text-slate-800">{advice.name}</h4>
                      </div>
                      <span className={`rounded-full px-2.5 py-1 text-[10px] font-bold border ${advice.statusStyle}`}>
                        {advice.status}
                      </span>
                    </div>

                    {/* Numeric breakdown cards */}
                    <div className="grid grid-cols-3 gap-2.5 mb-4 text-center">
                      <div className="rounded-xl bg-slate-50 p-2 border border-slate-100/60">
                        <span className="text-[9px] text-slate-400 block font-semibold">日均客用量</span>
                        <span className="text-xs font-bold text-indigo-600 block mt-0.5">
                          {advice.avgDailyConsume.toFixed(1)} {advice.unit}
                        </span>
                      </div>
                      
                      <div className="rounded-xl bg-slate-50 p-2 border border-slate-100/60">
                        <span className="text-[9px] text-slate-400 block font-semibold">日均報廢量</span>
                        <span className="text-xs font-bold text-rose-600 block mt-0.5">
                          {advice.avgDailyWaste.toFixed(1)} {advice.unit}
                        </span>
                      </div>

                      <div className="rounded-xl bg-indigo-50/30 p-2 border border-indigo-100/30">
                        <span className="text-[9px] text-indigo-500 block font-bold">建議大廳安全水位</span>
                        <span className="text-xs font-black text-indigo-700 block mt-0.5">
                          {advice.safetyStock} {advice.unit}
                        </span>
                      </div>
                    </div>

                    {/* Written Strategic Advice */}
                    <div className="rounded-xl bg-slate-50 p-4 border border-slate-100 text-xs text-slate-600 leading-relaxed mb-4">
                      <span className="font-bold text-slate-800 block mb-1">💡 營運精進改善方針：</span>
                      {advice.adviceText}
                    </div>
                  </div>

                  {/* Profitability indicators */}
                  <div className="border-t border-slate-50 pt-3.5 flex items-center justify-between text-[11px] font-medium text-slate-400">
                    <span className="flex items-center gap-1">
                      本期客用率: <span className="font-bold text-indigo-600">{advice.consumeRate.toFixed(0)}%</span>
                    </span>
                    <span className="flex items-center gap-1">
                      本期報廢率: <span className="font-bold text-rose-600">{advice.wasteRate.toFixed(0)}%</span>
                    </span>
                  </div>
                </div>
              ))}
            </div>

            {/* Global Cost Savings Advice summary */}
            <div className="rounded-2xl border border-slate-100 bg-white p-6 shadow-sm space-y-4">
              <h4 className="text-sm font-extrabold text-slate-800 flex items-center gap-2">
                <CheckCircle2 className="h-5 w-5 text-emerald-500" />
                大廳水果陳列與採購防損控管守則
              </h4>

              <div className="grid grid-cols-1 md:grid-cols-3 gap-4 text-xs">
                <div className="space-y-1 bg-slate-50 p-4 rounded-xl border border-slate-100">
                  <span className="font-bold text-slate-800 block">1. 依安全水位彈性陳列</span>
                  <p className="text-slate-500 leading-relaxed">
                    大廳擺放數量請以各水果「建議安全水位」為上限。不堆高、不溢滿，避免水果在常溫下加速熟化與壓迫損傷，有效控制日常損耗。
                  </p>
                </div>

                <div className="space-y-1 bg-slate-50 p-4 rounded-xl border border-slate-100">
                  <span className="font-bold text-slate-800 block">2. 採購總量動態微調</span>
                  <p className="text-slate-500 leading-relaxed">
                    若連續數天特定水果日均報廢量大於客用量，應立即向下修正 30% 採購總量，改用高週轉、易保存水果代替，精控耗材預算。
                  </p>
                </div>

                <div className="space-y-1 bg-slate-50 p-4 rounded-xl border border-slate-100">
                  <span className="font-bold text-slate-800 block">3. 大廳擺盤先進先出</span>
                  <p className="text-slate-500 leading-relaxed">
                    新進水果請置於陳列底層或後方，舊有水果移置前列或頂層，促使旅客優先拿取，並定時清點不佳品，防止整盤過熟報廢。
                  </p>
                </div>
              </div>
            </div>

          </div>
        )}

      </div>

    </div>
  );
}
