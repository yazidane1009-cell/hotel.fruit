/**
 * @license
 * SPDX-License-Identifier: Apache-2.0
 */

import React, { useState, useMemo } from 'react';
import { jsPDF } from 'jspdf';
import { LogEntry, FruitType } from '../types';
import { formatCurrency } from '../utils';
import { 
  BarChart, 
  Bar, 
  XAxis, 
  YAxis, 
  CartesianGrid, 
  Tooltip, 
  Legend, 
  ResponsiveContainer 
} from 'recharts';
import { 
  CalendarDays, 
  Layers, 
  TrendingUp, 
  DollarSign, 
  ShoppingBag, 
  Trash2, 
  ChevronRight, 
  ChevronDown, 
  PlusCircle,
  HelpCircle,
  AlertTriangle,
  Sparkles
} from 'lucide-react';
import { motion, AnimatePresence } from 'motion/react';

interface PeriodicStatsProps {
  logs: LogEntry[];
  fruits: FruitType[];
}

type PeriodType = 'day' | 'week' | 'month' | 'quarter' | 'year';

interface FruitPeriodStats {
  fruitId: string;
  fruitName: string;
  unit: string;
  defaultCost: number;
  supplyQty: number;
  supplyCost: number;
  consumptionQty: number;
  consumptionCost: number;
  wastageQty: number;
  wastageCost: number;
}

interface PeriodAggregate {
  periodKey: string;
  periodLabel: string;
  logsCount: number;
  supplyQty: number;
  supplyCost: number;
  consumptionQty: number;
  consumptionCost: number;
  wastageQty: number;
  wastageCost: number;
  wasteRate: number;
  consumptionRate: number;
  fruitDetails: Record<string, FruitPeriodStats>;
}

export default function PeriodicStats({ logs, fruits }: PeriodicStatsProps) {
  const [periodType, setPeriodType] = useState<PeriodType>('week');
  const [selectedPeriodKey, setSelectedPeriodKey] = useState<string | null>(null);

  const fruitMap = useMemo(() => new Map(fruits.map(f => [f.id, f])), [fruits]);

  // --- Date Grouping Helpers ---
  const dateHelpers = useMemo(() => {
    return {
      getDayKeyAndLabel: (timestamp: number) => {
        const d = new Date(timestamp);
        const y = d.getFullYear();
        const m = String(d.getMonth() + 1).padStart(2, '0');
        const dateStr = String(d.getDate()).padStart(2, '0');
        const key = `${y}-${m}-${dateStr}`;
        const label = `${y}年${m}月${dateStr}日`;
        return { key, label };
      },
      getWeekKeyAndLabel: (timestamp: number) => {
        const date = new Date(timestamp);
        // Find Monday of the week
        const day = date.getDay();
        const diff = date.getDate() - day + (day === 0 ? -6 : 1);
        const monday = new Date(date.setDate(diff));
        monday.setHours(0,0,0,0);
        
        const sunday = new Date(monday);
        sunday.setDate(monday.getDate() + 6);
        sunday.setHours(23,59,59,999);
        
        const y = monday.getFullYear();
        const mm1 = String(monday.getMonth() + 1).padStart(2, '0');
        const dd1 = String(monday.getDate()).padStart(2, '0');
        const mm2 = String(sunday.getMonth() + 1).padStart(2, '0');
        const dd2 = String(sunday.getDate()).padStart(2, '0');
        
        // Calculate ISO Week Number
        const target = new Date(timestamp);
        const dayNum = (target.getDay() + 6) % 7;
        target.setDate(target.getDate() - dayNum + 3);
        const firstThursday = target.valueOf();
        target.setMonth(0, 1);
        if (target.getDay() !== 4) {
          target.setMonth(0, 1 + ((4 - target.getDay() + 7) % 7));
        }
        const weekNum = 1 + Math.ceil((firstThursday - target.valueOf()) / 604800000);
        
        const key = `${y}-W${String(weekNum).padStart(2, '0')}`;
        const label = `${y}年第 ${weekNum} 週 (${mm1}/${dd1} - ${mm2}/${dd2})`;
        return { key, label };
      },
      getMonthKeyAndLabel: (timestamp: number) => {
        const d = new Date(timestamp);
        const y = d.getFullYear();
        const m = String(d.getMonth() + 1).padStart(2, '0');
        const key = `${y}-${m}`;
        const label = `${y}年 ${m}月`;
        return { key, label };
      },
      getQuarterKeyAndLabel: (timestamp: number) => {
        const d = new Date(timestamp);
        const y = d.getFullYear();
        const q = Math.floor(d.getMonth() / 3) + 1;
        const key = `${y}-Q${q}`;
        const label = `${y}年 第 ${q} 季 (Q${q})`;
        return { key, label };
      },
      getYearKeyAndLabel: (timestamp: number) => {
        const d = new Date(timestamp);
        const y = d.getFullYear();
        const key = `${y}`;
        const label = `${y}年度`;
        return { key, label };
      }
    };
  }, []);

  // --- Group & Aggregate Logs ---
  const periodicAggregates = useMemo(() => {
    const aggregates: Record<string, PeriodAggregate> = {};

    logs.forEach(log => {
      // Get key and label depending on selection
      let group = { key: '', label: '' };
      if (periodType === 'day') group = dateHelpers.getDayKeyAndLabel(log.timestamp);
      else if (periodType === 'week') group = dateHelpers.getWeekKeyAndLabel(log.timestamp);
      else if (periodType === 'month') group = dateHelpers.getMonthKeyAndLabel(log.timestamp);
      else if (periodType === 'quarter') group = dateHelpers.getQuarterKeyAndLabel(log.timestamp);
      else if (periodType === 'year') group = dateHelpers.getYearKeyAndLabel(log.timestamp);

      const { key, label } = group;

      if (!aggregates[key]) {
        // Initialize aggregate record
        const fruitDetailsInit: Record<string, FruitPeriodStats> = {};
        fruits.forEach(f => {
          fruitDetailsInit[f.id] = {
            fruitId: f.id,
            fruitName: f.name,
            unit: f.unit,
            defaultCost: f.defaultCost,
            supplyQty: 0,
            supplyCost: 0,
            consumptionQty: 0,
            consumptionCost: 0,
            wastageQty: 0,
            wastageCost: 0
          };
        });

        aggregates[key] = {
          periodKey: key,
          periodLabel: label,
          logsCount: 0,
          supplyQty: 0,
          supplyCost: 0,
          consumptionQty: 0,
          consumptionCost: 0,
          wastageQty: 0,
          wastageCost: 0,
          wasteRate: 0,
          consumptionRate: 0,
          fruitDetails: fruitDetailsInit
        };
      }

      const agg = aggregates[key];
      agg.logsCount += 1;

      // Safe check for fruit details (if a fruit was added later)
      if (!agg.fruitDetails[log.fruitId]) {
        const fruit = fruitMap.get(log.fruitId);
        agg.fruitDetails[log.fruitId] = {
          fruitId: log.fruitId,
          fruitName: fruit ? fruit.name : '自訂水果',
          unit: fruit ? fruit.unit : '個',
          defaultCost: fruit ? fruit.defaultCost : 10,
          supplyQty: 0,
          supplyCost: 0,
          consumptionQty: 0,
          consumptionCost: 0,
          wastageQty: 0,
          wastageCost: 0
        };
      }

      const fruitDetail = agg.fruitDetails[log.fruitId];

      if (log.type === 'supply') {
        agg.supplyQty += log.quantity;
        agg.supplyCost += log.cost;
        fruitDetail.supplyQty += log.quantity;
        fruitDetail.supplyCost += log.cost;
      } else if (log.type === 'consumption') {
        agg.consumptionQty += log.quantity;
        agg.consumptionCost += log.cost;
        fruitDetail.consumptionQty += log.quantity;
        fruitDetail.consumptionCost += log.cost;
      } else if (log.type === 'wastage') {
        agg.wastageQty += log.quantity;
        agg.wastageCost += log.cost;
        fruitDetail.wastageQty += log.quantity;
        fruitDetail.wastageCost += log.cost;
      }
    });

    // Post-process rates for each aggregate
    Object.values(aggregates).forEach(agg => {
      agg.wasteRate = agg.supplyQty > 0 ? (agg.wastageQty / agg.supplyQty) * 100 : 0;
      agg.consumptionRate = agg.supplyQty > 0 ? (agg.consumptionQty / agg.supplyQty) * 100 : 0;
    });

    // Sort chronologically (newest first for the table list)
    return Object.values(aggregates).sort((a, b) => b.periodKey.localeCompare(a.periodKey));
  }, [logs, fruits, periodType, dateHelpers, fruitMap]);

  // --- Selected Period Breakdown for Detail Viewer ---
  const selectedPeriodDetail = useMemo(() => {
    if (!selectedPeriodKey) return null;
    return periodicAggregates.find(agg => agg.periodKey === selectedPeriodKey) || null;
  }, [periodicAggregates, selectedPeriodKey]);

  // Auto-select the first period if none is selected
  React.useEffect(() => {
    if (periodicAggregates.length > 0) {
      // Find if current selection is still valid, else select first
      const exists = periodicAggregates.some(agg => agg.periodKey === selectedPeriodKey);
      if (!exists) {
        setSelectedPeriodKey(periodicAggregates[0].periodKey);
      }
    } else {
      setSelectedPeriodKey(null);
    }
  }, [periodicAggregates, selectedPeriodKey]);

  // --- Chart Data for visual comparisons ---
  const chartData = useMemo(() => {
    // Take up to 10 periods, sorted chronologically (oldest to newest) for a beautiful flow
    return [...periodicAggregates]
      .slice(0, 10)
      .reverse()
      .map(agg => ({
        name: agg.periodKey.replace(/^\d{4}-/, ''), // simplified name e.g. "07-16" or "W29"
        fullName: agg.periodLabel,
        '進貨價值': agg.supplyCost,
        '客用價值': agg.consumptionCost,
        '報廢損失': agg.wastageCost,
        '進貨量': agg.supplyQty,
        '食用量': agg.consumptionQty,
        '報廢量': agg.wastageQty,
      }));
  }, [periodicAggregates]);

  const handleExportPDF = () => {
    if (!selectedPeriodDetail) return;

    const doc = new jsPDF({
      orientation: 'portrait',
      unit: 'mm',
      format: 'a4'
    });

    const periodLabel = selectedPeriodDetail.periodLabel;
    
    // Header section with dark slate background
    doc.setFillColor(30, 41, 59); // slate-800
    doc.rect(0, 0, 210, 38, 'F');

    doc.setTextColor(255, 255, 255);
    doc.setFont('helvetica', 'bold');
    doc.setFontSize(16);
    doc.text('HOTEL LOBBY FRUIT AUDIT REPORT', 105, 14, { align: 'center' });
    
    doc.setFont('helvetica', 'normal');
    doc.setFontSize(9);
    doc.setTextColor(203, 213, 225); // slate-300
    doc.text('Welcome Fruit Periodic Audit & Loss Control Statement', 105, 21, { align: 'center' });
    
    doc.setFontSize(8);
    doc.text(`Period Covered: ${periodLabel} | Generated on: ${new Date().toLocaleDateString()}`, 105, 28, { align: 'center' });

    // Report Metadata Section
    doc.setTextColor(30, 41, 59); // slate-800
    doc.setFont('helvetica', 'bold');
    doc.setFontSize(10);
    doc.text('1. REPORT METADATA (Basic Information)', 15, 48);

    doc.setDrawColor(226, 232, 240); // slate-200
    doc.setLineWidth(0.5);
    doc.line(15, 51, 195, 51);

    doc.setFont('helvetica', 'normal');
    doc.setFontSize(9);
    doc.setTextColor(71, 85, 105); // slate-600
    doc.text(`Accounting Period : ${periodLabel}`, 18, 58);
    doc.text(`Audit Frequency   : ${periodType.toUpperCase()}`, 18, 64);
    doc.text(`Generated At      : ${new Date().toLocaleString()}`, 120, 58);
    doc.text(`Auditing Dept     : Hotel Guest Experience & Operations`, 120, 64);

    // KPI Summary Section
    doc.setFont('helvetica', 'bold');
    doc.setFontSize(10);
    doc.setTextColor(30, 41, 59);
    doc.text('2. FINANCIAL PERFORMANCE & EFFICIENCY', 15, 76);
    doc.line(15, 79, 195, 79);

    // Draw three KPI Blocks
    // Box 1: Supply (Purchase)
    doc.setFillColor(248, 250, 252); // slate-50
    doc.setDrawColor(226, 232, 240);
    doc.rect(15, 84, 56, 22, 'FD');
    doc.setTextColor(100, 116, 139); // slate-500
    doc.setFontSize(7.5);
    doc.setFont('helvetica', 'bold');
    doc.text('TOTAL SUPPLY COST (Purchase)', 18, 89);
    doc.setTextColor(16, 185, 129); // emerald-500
    doc.setFontSize(11);
    doc.text(formatCurrency(selectedPeriodDetail.supplyCost) + ' TWD', 18, 97);

    // Box 2: Consumed (Welcome Guest)
    doc.setFillColor(248, 250, 252);
    doc.rect(77, 84, 56, 22, 'FD');
    doc.setTextColor(100, 116, 139);
    doc.setFontSize(7.5);
    doc.text('GUEST CONSUMED (Value)', 80, 89);
    doc.setTextColor(99, 102, 241); // indigo-500
    doc.setFontSize(11);
    doc.text(formatCurrency(selectedPeriodDetail.consumptionCost) + ' TWD', 80, 97);

    // Box 3: Wastage Loss
    doc.setFillColor(248, 250, 252);
    doc.rect(139, 84, 56, 22, 'FD');
    doc.setTextColor(100, 116, 139);
    doc.setFontSize(7.5);
    doc.text('WASTAGE LOSS (Wasted)', 142, 89);
    doc.setTextColor(239, 68, 68); // rose-500
    doc.setFontSize(11);
    doc.text(formatCurrency(selectedPeriodDetail.wastageCost) + ' TWD', 142, 97);

    // Efficiency Indicators underneath
    doc.setFont('helvetica', 'normal');
    doc.setFontSize(8.5);
    doc.setTextColor(71, 85, 105);
    doc.text(`Guest Consumption Rate (Customer Use):  ${selectedPeriodDetail.consumptionRate.toFixed(1)}%`, 18, 113);
    doc.text(`Inventory Wastage Rate (Lobby Loss):  ${selectedPeriodDetail.wasteRate.toFixed(1)}%`, 120, 113);

    // Draw efficiency progress bar indicator
    doc.setFillColor(241, 245, 249); // slate-100
    doc.rect(18, 116, 80, 2, 'F');
    doc.setFillColor(99, 102, 241); // indigo
    doc.rect(18, 116, Math.min(80, selectedPeriodDetail.consumptionRate * 0.8), 2, 'F');

    doc.setFillColor(241, 245, 249);
    doc.rect(120, 116, 75, 2, 'F');
    doc.setFillColor(239, 68, 68); // rose
    doc.rect(120, 116, Math.min(75, selectedPeriodDetail.wasteRate * 0.75), 2, 'F');

    // Detailed Table Section
    doc.setFont('helvetica', 'bold');
    doc.setFontSize(10);
    doc.setTextColor(30, 41, 59);
    doc.text('3. DETAILED FRUIT ACCOUNTING BREAKDOWN (Fruit Details)', 15, 128);
    doc.line(15, 131, 195, 131);

    // Table Header
    doc.setFillColor(241, 245, 249); // slate-100
    doc.rect(15, 135, 180, 8, 'F');
    doc.setFontSize(8);
    doc.setTextColor(51, 65, 85); // slate-700
    doc.text('Fruit Name', 18, 140);
    doc.text('Unit Price', 58, 140);
    doc.text('Supply (Qty / Cost)', 80, 140);
    doc.text('Consumed (Qty / Value)', 118, 140);
    doc.text('Wasted (Qty / Loss)', 156, 140);
    doc.text('Waste %', 184, 140);

    const CHINESE_FRUIT_MAP: Record<string, string> = {
      '蘋果': 'Apple',
      '香蕉': 'Banana',
      '柳橙': 'Orange',
      '柳丁': 'Orange',
      '橘子': 'Mandarin',
      '梨子': 'Pear',
      '奇異果': 'Kiwi',
      '葡萄': 'Grape',
      '芭樂': 'Guava',
      '番茄': 'Tomato',
      '西瓜': 'Watermelon',
      '木瓜': 'Papaya',
      '芒果': 'Mango',
      '鳳梨': 'Pineapple',
      '草莓': 'Strawberry',
      '哈密瓜': 'Melon',
      '蓮霧': 'Wax Apple'
    };

    function getSafeFruitName(name: string): string {
      const match = name.match(/\(([^)]+)\)/);
      if (match && match[1]) {
        return match[1].trim();
      }
      for (const [zh, en] of Object.entries(CHINESE_FRUIT_MAP)) {
        if (name.includes(zh)) {
          return en;
        }
      }
      const asciiOnly = name.replace(/[^\x00-\x7F]/g, '').trim();
      return asciiOnly || 'Fruit';
    }

    let currentY = 148;
    const fDetails = Object.keys(selectedPeriodDetail.fruitDetails)
      .map(key => selectedPeriodDetail.fruitDetails[key])
      .filter(f => f.supplyQty > 0 || f.consumptionQty > 0 || f.wastageQty > 0);

    doc.setFont('helvetica', 'normal');
    doc.setFontSize(8);
    doc.setTextColor(71, 85, 105);

    fDetails.forEach((f) => {
      const displayFruitName = getSafeFruitName(f.fruitName);
      
      doc.text(displayFruitName, 18, currentY);
      doc.text(formatCurrency(f.defaultCost), 58, currentY);
      doc.text(`${f.supplyQty} / ${formatCurrency(f.supplyCost)}`, 80, currentY);
      doc.text(`${f.consumptionQty} / ${formatCurrency(f.consumptionCost)}`, 118, currentY);
      doc.text(`${f.wastageQty} / ${formatCurrency(f.wastageCost)}`, 156, currentY);
      
      const rate = f.supplyQty > 0 ? (f.wastageQty / f.supplyQty) * 100 : 0;
      doc.text(`${rate.toFixed(0)}%`, 184, currentY);

      // Draw light separator line
      doc.setDrawColor(241, 245, 249);
      doc.line(15, currentY + 3, 195, currentY + 3);
      currentY += 8;
    });

    // Draw total row
    doc.setFont('helvetica', 'bold');
    doc.setTextColor(15, 23, 42); // slate-900
    doc.text('TOTAL SUMMARY', 18, currentY + 2);
    doc.text('-', 58, currentY + 2);
    doc.text(`${selectedPeriodDetail.supplyQty} / ${formatCurrency(selectedPeriodDetail.supplyCost)}`, 80, currentY + 2);
    doc.text(`${selectedPeriodDetail.consumptionQty} / ${formatCurrency(selectedPeriodDetail.consumptionCost)}`, 118, currentY + 2);
    doc.text(`${selectedPeriodDetail.wastageQty} / ${formatCurrency(selectedPeriodDetail.wastageCost)}`, 156, currentY + 2);
    doc.text(`${selectedPeriodDetail.wasteRate.toFixed(1)}%`, 184, currentY + 2);

    doc.setDrawColor(148, 163, 184); // slate-400
    doc.line(15, currentY + 5, 195, currentY + 5);

    // Operational Guidelines Section (at bottom of the page)
    const directivesY = Math.max(currentY + 16, 210);
    doc.setFont('helvetica', 'bold');
    doc.setFontSize(10);
    doc.setTextColor(30, 41, 59);
    doc.text('4. LOSS CONTROL DIRECTIVES & MITIGATION GUIDELINES', 15, directivesY);
    doc.setDrawColor(226, 232, 240);
    doc.line(15, directivesY + 3, 195, directivesY + 3);

    doc.setFillColor(248, 250, 252);
    doc.rect(15, directivesY + 6, 180, 25, 'F');
    
    doc.setFont('helvetica', 'bold');
    doc.setFontSize(8);
    doc.setTextColor(51, 65, 85);
    doc.text('* DISPLAY ROTATION (FIFO Policy)', 18, directivesY + 11);
    doc.setFont('helvetica', 'normal');
    doc.setTextColor(100, 116, 139);
    doc.text('  Rotate fruit display on lobby plates continuously. Place fresh arrivals at the bottom / back to speed up use.', 18, directivesY + 15);
    
    doc.setFont('helvetica', 'bold');
    doc.setTextColor(51, 65, 85);
    doc.text('* INTENTIONAL PROCUREMENT WATER LEVEL', 18, directivesY + 20);
    doc.setFont('helvetica', 'normal');
    doc.setTextColor(100, 116, 139);
    doc.text('  If the wastage rate of an item exceeds 15% for the period, scale down lobby display stock limits by 30%.', 18, directivesY + 24);

    // Footer copyright
    doc.setFontSize(7);
    doc.setTextColor(148, 163, 184);
    doc.text('Welcome Fruit Audit and Cost Control System - Operational Intelligence Document', 105, 285, { align: 'center' });

    doc.save(`Hotel_Fruit_Audit_Report_${periodLabel.replace(/\s+/g, '_')}.pdf`);
  };

  return (
    <div id="periodic_financial_stats_section" className="space-y-6">
      
      {/* 1. Statistics Selector Panel */}
      <div className="rounded-2xl border border-slate-100 bg-white p-6 shadow-sm">
        <div className="flex flex-col justify-between gap-5 border-b border-slate-50 pb-5 md:flex-row md:items-center">
          <div>
            <h3 className="flex items-center gap-2 text-md font-extrabold text-slate-900">
              <CalendarDays className="h-5 w-5 text-emerald-500" />
              週期統計分析
            </h3>
          </div>

          {/* Grouping Tab buttons */}
          <div className="flex gap-1 rounded-xl bg-slate-100 p-1 self-start md:self-center">
            {(['day', 'week', 'month', 'quarter', 'year'] as PeriodType[]).map(tab => (
              <button
                key={tab}
                id={`stat_tab_${tab}`}
                onClick={() => {
                  setPeriodType(tab);
                  setSelectedPeriodKey(null);
                }}
                className={`rounded-lg px-3.5 py-1.5 text-xs font-bold transition-all cursor-pointer ${
                  periodType === tab
                    ? 'bg-white text-emerald-600 shadow-xs'
                    : 'text-slate-500 hover:text-slate-900'
                }`}
              >
                {tab === 'day' && '日統計 (Daily)'}
                {tab === 'week' && '週統計 (Weekly)'}
                {tab === 'month' && '月統計 (Monthly)'}
                {tab === 'quarter' && '季統計 (Quarterly)'}
                {tab === 'year' && '年統計 (Yearly)'}
              </button>
            ))}
          </div>
        </div>

        {/* 2. Visual Period Comparison Chart */}
        {chartData.length > 0 && (
          <div className="mt-5 space-y-3">
            <div className="flex items-center justify-between">
              <span className="text-xs font-bold text-slate-700 flex items-center gap-1">
                <TrendingUp className="h-3.5 w-3.5 text-indigo-500" />
                近期週期財務與損耗走勢 (進貨價值 vs 食用價值 vs 報廢損失)
              </span>
              <span className="text-[10px] text-slate-400">顯示最近 10 個統計區間</span>
            </div>
            
            <div className="h-[200px] w-full">
              <ResponsiveContainer width="100%" height="100%">
                <BarChart data={chartData} margin={{ top: 10, right: 10, left: -10, bottom: 0 }}>
                  <CartesianGrid strokeDasharray="3 3" vertical={false} stroke="#f1f5f9" />
                  <XAxis 
                    dataKey="name" 
                    tickLine={false} 
                    axisLine={false} 
                    tick={{ fontSize: 10, fill: '#64748b', fontWeight: 600 }}
                  />
                  <YAxis 
                    tickLine={false} 
                    axisLine={false} 
                    tick={{ fontSize: 10, fill: '#64748b' }}
                    tickFormatter={(v) => `$${v}`}
                  />
                  <Tooltip 
                    contentStyle={{ borderRadius: '12px', border: '1px solid #f1f5f9', fontSize: '11px', boxShadow: '0 4px 12px rgba(0,0,0,0.05)' }} 
                    formatter={(value) => [formatCurrency(Number(value)), '']}
                  />
                  <Legend iconType="circle" iconSize={6} wrapperStyle={{ fontSize: '10px', fontWeight: 600 }} />
                  <Bar dataKey="進貨價值" fill="#10b981" radius={[3, 3, 0, 0]} maxBarSize={16} />
                  <Bar dataKey="客用價值" fill="#6366f1" radius={[3, 3, 0, 0]} maxBarSize={16} />
                  <Bar dataKey="報廢損失" fill="#f43f5e" radius={[3, 3, 0, 0]} maxBarSize={16} />
                </BarChart>
              </ResponsiveContainer>
            </div>
          </div>
        )}
      </div>

      {/* 3. Main Data split: Left is Period Aggregates List, Right is Details Drill-down */}
      <div className="grid grid-cols-1 gap-6 lg:grid-cols-3">
        
        {/* A. Grouped Period Table (2/3 Width) */}
        <div className="rounded-2xl border border-slate-100 bg-white p-6 shadow-sm lg:col-span-2">
          <div className="mb-4">
            <h4 className="text-sm font-bold text-slate-800">
              {periodType === 'day' && '每日迎賓水果明細'}
              {periodType === 'week' && '每週迎賓水果明細'}
              {periodType === 'month' && '每月迎賓水果明細'}
              {periodType === 'quarter' && '每季迎賓水果明細'}
              {periodType === 'year' && '年度財務核銷明細'}
            </h4>
            <p className="text-xs text-slate-400">點擊任意區間即可在右側檢視各項水果的「單價、總價、數量」細部交叉統計</p>
          </div>

          <div className="overflow-x-auto rounded-xl border border-slate-100">
            <table className="w-full text-left text-xs">
              <thead>
                <tr className="border-b border-slate-100 bg-slate-50/70 text-slate-500 font-semibold whitespace-nowrap">
                  <th className="p-3">區間段落</th>
                  <th className="p-3">進貨 (補貨上架)</th>
                  <th className="p-3">客用 (用量統計)</th>
                  <th className="p-3">報廢 (防損損失)</th>
                  <th className="p-3 text-center">報廢率 %</th>
                  <th className="p-3 text-right">稽核</th>
                </tr>
              </thead>
              <tbody className="divide-y divide-slate-50 text-slate-600">
                {periodicAggregates.length === 0 ? (
                  <tr>
                    <td colSpan={6} className="p-8 text-center text-slate-400">
                      尚未輸入任何迎賓水果流水資料。
                    </td>
                  </tr>
                ) : (
                  periodicAggregates.map(agg => {
                    const isSelected = selectedPeriodKey === agg.periodKey;
                    const highWaste = agg.wasteRate > 20;

                    return (
                      <tr 
                        key={agg.periodKey}
                        onClick={() => setSelectedPeriodKey(agg.periodKey)}
                        className={`group cursor-pointer transition-all hover:bg-slate-50/80 ${
                          isSelected ? 'bg-indigo-50/40 text-indigo-950 font-medium' : ''
                        }`}
                      >
                        {/* Period label */}
                        <td className="p-3 font-semibold text-slate-950 flex items-center gap-1">
                          <ChevronRight className={`h-3 w-3 text-slate-400 group-hover:text-slate-600 transition ${
                            isSelected ? 'rotate-90 text-indigo-500' : ''
                          }`} />
                          {agg.periodLabel}
                        </td>

                        {/* Supply */}
                        <td className="p-3">
                          <span className="font-bold text-slate-800">{agg.supplyQty}個</span>
                          <span className="block text-[10px] text-slate-400 font-medium">
                            {formatCurrency(agg.supplyCost)}
                          </span>
                        </td>

                        {/* Consumption */}
                        <td className="p-3">
                          <span className="font-bold text-indigo-600">{agg.consumptionQty}個</span>
                          <span className="block text-[10px] text-slate-400 font-medium">
                            {formatCurrency(agg.consumptionCost)}
                          </span>
                        </td>

                        {/* Wastage */}
                        <td className="p-3">
                          <span className={`font-bold ${agg.wastageQty > 0 ? 'text-rose-600' : 'text-slate-500'}`}>
                            {agg.wastageQty}個
                          </span>
                          <span className="block text-[10px] text-slate-400 font-medium">
                            {formatCurrency(agg.wastageCost)}
                          </span>
                        </td>

                        {/* Wastage Rate */}
                        <td className="p-3 text-center">
                          <span className={`inline-flex items-center gap-0.5 rounded-full px-2 py-0.5 text-[10px] font-bold border ${
                            highWaste 
                              ? 'bg-rose-50 text-rose-700 border-rose-100 animate-pulse' 
                              : agg.wasteRate > 10 
                                ? 'bg-amber-50 text-amber-700 border-amber-100'
                                : 'bg-emerald-50 text-emerald-700 border-emerald-100'
                          }`}>
                            {agg.wasteRate.toFixed(1)}%
                          </span>
                        </td>

                        {/* Select helper */}
                        <td className="p-3 text-right">
                          <span className={`text-[10px] font-bold uppercase transition ${
                            isSelected ? 'text-indigo-600' : 'text-slate-400 group-hover:text-slate-600'
                          }`}>
                            {isSelected ? '檢視中' : '點選'}
                          </span>
                        </td>
                      </tr>
                    );
                  })
                )}
              </tbody>
            </table>
          </div>
        </div>

        {/* B. Drill-down Fruit-level Breakdown Panel (1/3 Width) */}
        <div className="rounded-2xl border border-indigo-100 bg-white shadow-sm overflow-hidden flex flex-col justify-between">
          
          {/* Panel Header */}
          <div className="bg-indigo-50/50 p-5 border-b border-indigo-100/50 flex flex-col sm:flex-row sm:items-center justify-between gap-3">
            <div>
              <span className="text-[10px] font-extrabold text-indigo-600 tracking-wide uppercase">細部單價與總價帳務交叉稽核</span>
              <h4 className="text-md font-extrabold text-slate-900 mt-1">
                {selectedPeriodDetail ? selectedPeriodDetail.periodLabel : '未選取區間'}
              </h4>
              <p className="text-[11px] text-slate-500 mt-1">包含進貨、客用、報廢的水果單價與個別小計</p>
            </div>
            {selectedPeriodDetail && (
              <button
                id="btn_export_pdf"
                onClick={handleExportPDF}
                className="flex items-center justify-center gap-1.5 rounded-xl bg-gradient-to-r from-emerald-500 to-teal-600 px-3.5 py-2 text-xs font-bold text-white shadow-xs transition-all hover:brightness-105 active:scale-98 cursor-pointer shrink-0"
              >
                <Sparkles className="h-3.5 w-3.5" />
                匯出 PDF 報表
              </button>
            )}
          </div>

          {/* Panel Content */}
          <div className="flex-1 p-5 overflow-y-auto max-h-[380px] space-y-4">
            {!selectedPeriodDetail ? (
              <div className="flex flex-col items-center justify-center text-center text-slate-400 py-16">
                <HelpCircle className="h-10 w-10 stroke-[1.2] mb-3 text-slate-300" />
                <p className="text-xs">請點擊左側列表的任一日期或週別，即可展開當期的水果對帳單。</p>
              </div>
            ) : (
              <div className="space-y-4.5">
                {Object.keys(selectedPeriodDetail.fruitDetails)
                  .map(key => selectedPeriodDetail.fruitDetails[key])
                  .filter(f => f.supplyQty > 0 || f.consumptionQty > 0 || f.wastageQty > 0)
                  .map(fDetail => {
                    return (
                      <div key={fDetail.fruitId} className="rounded-xl border border-slate-100 bg-slate-50/30 p-3.5 space-y-3 hover:border-slate-200 transition">
                        
                        {/* Title & Unit Cost */}
                        <div className="flex items-center justify-between border-b border-slate-100 pb-2">
                          <div className="flex items-center gap-2">
                            <span 
                              className="h-2.5 w-2.5 rounded-full shrink-0" 
                              style={{ backgroundColor: fruitMap.get(fDetail.fruitId)?.color || '#94a3b8' }} 
                            />
                            <span className="font-bold text-slate-800 text-xs">
                              {fDetail.fruitName}
                            </span>
                          </div>
                          
                          <span className="text-[10px] font-bold text-slate-500 bg-slate-100 rounded px-1.5 py-0.5">
                            單價：{formatCurrency(fDetail.defaultCost)} / {fDetail.unit}
                          </span>
                        </div>

                        {/* Breakdown Rows */}
                        <div className="space-y-2 text-[11px]">
                          {/* Supply */}
                          {fDetail.supplyQty > 0 && (
                            <div className="flex items-center justify-between">
                              <span className="text-slate-500 flex items-center gap-1 font-medium">
                                <span className="h-1.5 w-1.5 rounded-full bg-emerald-500" />
                                進貨上架：
                              </span>
                              <span className="font-semibold text-slate-800">
                                {fDetail.supplyQty} {fDetail.unit} 
                                <span className="text-slate-400 font-normal ml-1">
                                  (總價: {formatCurrency(fDetail.supplyCost)})
                                </span>
                              </span>
                            </div>
                          )}

                          {/* Consumption */}
                          {fDetail.consumptionQty > 0 && (
                            <div className="flex items-center justify-between">
                              <span className="text-slate-500 flex items-center gap-1 font-medium">
                                <span className="h-1.5 w-1.5 rounded-full bg-indigo-500" />
                                顧客用量：
                              </span>
                              <span className="font-semibold text-slate-800">
                                {fDetail.consumptionQty} {fDetail.unit}
                                <span className="text-indigo-600 font-medium ml-1">
                                  (價值: {formatCurrency(fDetail.consumptionCost)})
                                </span>
                              </span>
                            </div>
                          )}

                          {/* Wastage */}
                          {fDetail.wastageQty > 0 && (
                            <div className="flex items-center justify-between">
                              <span className="text-slate-500 flex items-center gap-1 font-medium">
                                <span className="h-1.5 w-1.5 rounded-full bg-rose-500" />
                                損耗報廢：
                              </span>
                              <span className="font-semibold text-rose-700">
                                {fDetail.wastageQty} {fDetail.unit}
                                <span className="text-rose-600 font-medium ml-1">
                                  (損失: {formatCurrency(fDetail.wastageCost)})
                                </span>
                              </span>
                            </div>
                          )}
                        </div>

                      </div>
                    );
                  })
                }

                {Object.keys(selectedPeriodDetail.fruitDetails)
                  .map(key => selectedPeriodDetail.fruitDetails[key])
                  .filter(f => f.supplyQty > 0 || f.consumptionQty > 0 || f.wastageQty > 0).length === 0 && (
                  <p className="text-xs text-slate-400 text-center py-6">此區間目前無任何水果流向資料。</p>
                )}
              </div>
            )}
          </div>

          {/* Panel Footer (Financial Balance summary) */}
          {selectedPeriodDetail && (
            <div className="bg-indigo-50/20 p-4 border-t border-indigo-50/60 text-xs font-semibold space-y-1.5 text-slate-700">
              <div className="flex justify-between">
                <span>當期採購進貨總額：</span>
                <span className="font-bold text-slate-900">{formatCurrency(selectedPeriodDetail.supplyCost)}</span>
              </div>
              <div className="flex justify-between">
                <span>旅客迎賓招待總價值：</span>
                <span className="font-bold text-indigo-600">{formatCurrency(selectedPeriodDetail.consumptionCost)}</span>
              </div>
              <div className="flex justify-between text-rose-600">
                <span>食材耗損報廢損失：</span>
                <span className="font-extrabold">{formatCurrency(selectedPeriodDetail.wastageCost)}</span>
              </div>
            </div>
          )}

        </div>

      </div>

    </div>
  );
}
