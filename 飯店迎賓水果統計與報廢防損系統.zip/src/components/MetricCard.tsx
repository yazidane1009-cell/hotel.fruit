/**
 * @license
 * SPDX-License-Identifier: Apache-2.0
 */

import React from 'react';
import * as LucideIcons from 'lucide-react';
import { motion } from 'motion/react';

interface MetricCardProps {
  id: string;
  title: string;
  value: string | number;
  subValue?: string;
  subValueColor?: string;
  iconName: keyof typeof LucideIcons;
  colorClass: string; // e.g. 'emerald', 'amber', 'rose', 'blue', 'indigo'
  description?: string;
  index: number;
}

export default function MetricCard({
  id,
  title,
  value,
  subValue,
  subValueColor = 'text-slate-500',
  iconName,
  colorClass,
  description,
  index,
}: MetricCardProps) {
  // Extract icon dynamically
  const IconComponent = LucideIcons[iconName] as React.ComponentType<{ className?: string }>;

  // Style map for backgrounds and borders based on colorClass
  const themeStyles: Record<string, { bg: string; text: string; lightBg: string; border: string }> = {
    emerald: {
      bg: 'bg-emerald-500',
      text: 'text-emerald-600',
      lightBg: 'bg-emerald-50/70',
      border: 'border-emerald-100',
    },
    rose: {
      bg: 'bg-rose-500',
      text: 'text-rose-600',
      lightBg: 'bg-rose-50/70',
      border: 'border-rose-100',
    },
    amber: {
      bg: 'bg-amber-500',
      text: 'text-amber-600',
      lightBg: 'bg-amber-50/70',
      border: 'border-amber-100',
    },
    indigo: {
      bg: 'bg-indigo-500',
      text: 'text-indigo-600',
      lightBg: 'bg-indigo-50/70',
      border: 'border-indigo-100',
    },
    sky: {
      bg: 'bg-sky-500',
      text: 'text-sky-600',
      lightBg: 'bg-sky-50/70',
      border: 'border-sky-100',
    },
  };

  const style = themeStyles[colorClass] || themeStyles.indigo;

  return (
    <motion.div
      id={id}
      initial={{ opacity: 0, y: 15 }}
      animate={{ opacity: 1, y: 0 }}
      transition={{ duration: 0.3, delay: index * 0.08 }}
      className={`relative overflow-hidden rounded-2xl border ${style.border} bg-white p-6 shadow-sm transition-all hover:shadow-md`}
    >
      {/* Decorative ambient background blur */}
      <div className={`absolute -right-10 -top-10 h-28 w-28 rounded-full ${style.lightBg} blur-2xl`} />

      <div className="flex items-center justify-between">
        <div className="space-y-1.5 z-10">
          <p className="text-xs font-medium tracking-wide text-slate-500 uppercase">{title}</p>
          <h3 className="text-3xl font-semibold tracking-tight text-slate-900">{value}</h3>
          {subValue && (
            <p className={`text-xs font-medium ${subValueColor} mt-1 flex items-center gap-1`}>
              {subValue}
            </p>
          )}
        </div>
        
        <div className={`rounded-xl p-3 ${style.lightBg} ${style.text} z-10`}>
          {IconComponent && <IconComponent className="h-6 w-6 stroke-[2]" />}
        </div>
      </div>
      
      {description && (
        <div className="mt-4 border-t border-slate-50 pt-2.5">
          <p className="text-[11px] text-slate-400 font-normal leading-relaxed">{description}</p>
        </div>
      )}
    </motion.div>
  );
}
