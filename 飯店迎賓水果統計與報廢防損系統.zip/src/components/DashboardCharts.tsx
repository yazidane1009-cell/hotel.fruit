/**
 * @license
 * SPDX-License-Identifier: Apache-2.0
 */

import React, { useState, useMemo } from 'react';
import {
  BarChart,
  Bar,
  XAxis,
  YAxis,
  CartesianGrid,
  Tooltip,
  Legend,
  ResponsiveContainer,
  PieChart,
  Pie,
  Cell,
  TooltipProps,
} from 'recharts';
import { LogEntry, FruitType } from '../types';
import { formatDateShort, formatCurrency } from '../utils';
import { BarChart3, PieChart as PieIcon, HelpCircle } from 'lucide-react';

interface DashboardChartsProps {
  logs: LogEntry[];
  fruits: FruitType[];
}

export default function DashboardCharts({ logs, fruits }: DashboardChartsProps) {
  const [startDateStr, setStartDateStr] = useState<string>(() => {
    const d = new Date();
    d.setDate(d.getDate() - 6);
    return d.toISOString().split('T')[0];
  });
  const [endDateStr, setEndDateStr] = useState<string>(() => {
    return new Date().toISOString().split('T')[0];
  });
  const [metricType, setMetricType] = useState<'quantity' | 'cost'>('quantity'); // quantity or cost
  const [breakdownTab, setBreakdownTab] = useState<'popularity' | 'wastage'>('popularity');

  const fruitMap = useMemo(() => new Map(fruits.map(f => [f.id, f])), [fruits]);

  // Determine if currently selected dates match one of our quick presets
  const activeQuickRange = useMemo(() => {
    const start = new Date(startDateStr);
    const end = new Date(endDateStr);
    start.setHours(0, 0, 0, 0);
    end.setHours(0, 0, 0, 0);
    const diffTime = Math.abs(end.getTime() - start.getTime());
    const diffDays = Math.ceil(diffTime / (1000 * 60 * 60 * 24));
    
    // Check if end matches today or is extremely close
    const todayStr = new Date().toISOString().split('T')[0];
    if (endDateStr === todayStr) {
      if (diffDays === 7) return 7;
      if (diffDays === 14) return 14;
      if (diffDays === 30) return 30;
    }
    return null;
  }, [startDateStr, endDateStr]);

  const handleSetQuickRange = (days: number) => {
    const end = new Date();
    const start = new Date();
    start.setDate(end.getDate() - (days - 1));
    setStartDateStr(start.toISOString().split('T')[0]);
    setEndDateStr(end.toISOString().split('T')[0]);
  };

  // --- Data Processing for Daily Trends ---
  const trendData = useMemo(() => {
    const dataMap: Record<string, { dateStr: string; dateMs: number; supply: number; consumption: number; wastage: number; supplyCost: number; consumptionCost: number; wastageCost: number }> = {};
    
    const start = new Date(startDateStr);
    const end = new Date(endDateStr);
    start.setHours(0, 0, 0, 0);
    end.setHours(0, 0, 0, 0);

    const actualStart = start <= end ? start : end;
    const actualEnd = start <= end ? end : start;

    const diffTime = Math.abs(actualEnd.getTime() - actualStart.getTime());
    const diffDays = Math.min(180, Math.ceil(diffTime / (1000 * 60 * 60 * 24))); // Cap at 180 days for chart performance

    const ONE_DAY = 24 * 60 * 60 * 1000;

    for (let i = 0; i <= diffDays; i++) {
      const dayMs = actualStart.getTime() + i * ONE_DAY;
      const d = new Date(dayMs);
      const dateKey = `${d.getFullYear()}-${String(d.getMonth() + 1).padStart(2, '0')}-${String(d.getDate()).padStart(2, '0')}`;
      dataMap[dateKey] = {
        dateStr: formatDateShort(dayMs),
        dateMs: dayMs,
        supply: 0,
        consumption: 0,
        wastage: 0,
        supplyCost: 0,
        consumptionCost: 0,
        wastageCost: 0,
      };
    }

    // Populate from actual logs
    logs.forEach(log => {
      const logDate = new Date(log.timestamp);
      const dateKey = `${logDate.getFullYear()}-${String(logDate.getMonth() + 1).padStart(2, '0')}-${String(logDate.getDate()).padStart(2, '0')}`;
      
      // If the log falls within our custom selected range
      if (dataMap[dateKey]) {
        if (log.type === 'supply') {
          dataMap[dateKey].supply += log.quantity;
          dataMap[dateKey].supplyCost += log.cost;
        } else if (log.type === 'consumption') {
          dataMap[dateKey].consumption += log.quantity;
          dataMap[dateKey].consumptionCost += log.cost;
        } else if (log.type === 'wastage') {
          dataMap[dateKey].wastage += log.quantity;
          dataMap[dateKey].wastageCost += log.cost;
        }
      }
    });

    // Return sorted by date
    return Object.values(dataMap).sort((a, b) => a.dateMs - b.dateMs);
  }, [logs, startDateStr, endDateStr]);

  // --- Data Processing for Fruit Consumption Popularity ---
  const consumptionPopularityData = useMemo(() => {
    const fruitTotals: Record<string, { name: string; value: number; cost: number; color: string }> = {};
    
    fruits.forEach(f => {
      fruitTotals[f.id] = { name: f.name.split(' ')[0], value: 0, cost: 0, color: f.color };
    });

    // Accumulate only consumption logs
    logs.forEach(log => {
      if (log.type === 'consumption' && fruitTotals[log.fruitId]) {
        fruitTotals[log.fruitId].value += log.quantity;
        fruitTotals[log.fruitId].cost += log.cost;
      }
    });

    // Filter out fruits with 0 consumption and map to array
    return Object.values(fruitTotals)
      .filter(f => f.value > 0)
      .sort((a, b) => b.value - a.value);
  }, [logs, fruits]);

  // --- Data Processing for Fruit Wastage Breakdown (by Fruit Type instead of Reason) ---
  const fruitWastageBreakdownData = useMemo(() => {
    const fruitTotals: Record<string, { name: string; quantity: number; cost: number; color: string }> = {};

    fruits.forEach(f => {
      fruitTotals[f.id] = { name: f.name.split(' ')[0], quantity: 0, cost: 0, color: f.color };
    });

    logs.forEach(log => {
      if (log.type === 'wastage' && fruitTotals[log.fruitId]) {
        fruitTotals[log.fruitId].quantity += log.quantity;
        fruitTotals[log.fruitId].cost += log.cost;
      }
    });

    return Object.values(fruitTotals)
      .filter(f => f.quantity > 0)
      .sort((a, b) => b.quantity - a.quantity);
  }, [logs, fruits]);

  // Chart colors for general categories
  const COLORS = {
    consumption: '#6366f1', // Indigo-500
    wastage: '#f43f5e',     // Rose-500
    supply: '#10b981',      // Emerald-500
    sub: ['#6366f1', '#f43f5e', '#3b82f6', '#10b981', '#fb923c', '#ec4899', '#8b5cf6', '#14b8a6']
  };

  // Custom tooltips to present numbers beautifully
  const renderCustomTooltip = ({ active, payload, label }: any) => {
    if (active && payload && payload.length) {
      return (
        <div className="rounded-xl border border-slate-100 bg-white p-3 shadow-lg text-xs space-y-1.5">
          <p className="font-bold text-slate-800 border-b border-slate-50 pb-1 mb-1">{label}</p>
          {payload.map((entry: any, index: number) => (
            <div key={index} className="flex items-center gap-2 justify-between">
              <span className="flex items-center gap-1.5 text-slate-500">
                <span className="h-2 w-2 rounded-full" style={{ backgroundColor: entry.color }} />
                {entry.name}:
              </span>
              <span className="font-bold text-slate-900">
                {metricType === 'cost' 
                  ? formatCurrency(entry.value || 0) 
                  : `${entry.value} ${(payload[0]?.payload as { unit?: string })?.unit || '個'}`}
              </span>
            </div>
          ))}
        </div>
      );
    }
    return null;
  };

  const renderPieTooltip = ({ active, payload }: any) => {
    if (active && payload && payload.length) {
      const data = payload[0].payload as { name: string; value: number; cost: number; percent: number };
      const percentVal = (payload[0].value || 0);
      return (
        <div className="rounded-xl border border-slate-100 bg-white p-3 shadow-lg text-xs">
          <p className="font-bold text-slate-800 mb-1">{data.name}</p>
          <div className="space-y-1">
            <div className="flex justify-between gap-4">
              <span className="text-slate-500">累計消耗：</span>
              <span className="font-bold text-slate-900">{data.value} 個</span>
            </div>
            <div className="flex justify-between gap-4">
              <span className="text-slate-500">佔比：</span>
              <span className="font-bold text-indigo-600">{percentVal.toFixed(1)}%</span>
            </div>
            <div className="flex justify-between gap-4 border-t border-slate-50 pt-1 mt-1">
              <span className="text-slate-500">材料價值：</span>
              <span className="font-bold text-slate-700">{formatCurrency(data.cost)}</span>
            </div>
          </div>
        </div>
      );
    }
    return null;
  };

  return (
    <div id="trend_chart_card" className="rounded-2xl border border-slate-100 bg-white p-6 shadow-sm w-full">
      <div className="mb-5 flex flex-col justify-between gap-4 sm:flex-row sm:items-center">
        <div>
          <h3 className="flex items-center gap-2 text-md font-semibold text-slate-900">
            <BarChart3 className="h-5 w-5 text-indigo-500" />
            使用趨勢
          </h3>
        </div>

        <div className="flex flex-wrap items-center gap-3">
          {/* Quick Presets */}
          <div className="flex items-center gap-1.5">
            <span className="text-[11px] font-bold text-slate-400">快速：</span>
            <div className="flex rounded-lg bg-slate-100 p-0.5">
              <button
                id="range_7d_btn"
                onClick={() => handleSetQuickRange(7)}
                className={`rounded-md px-2.5 py-1 text-[11px] font-semibold transition cursor-pointer ${
                  activeQuickRange === 7 ? 'bg-white text-slate-900 shadow-xs' : 'text-slate-500 hover:text-slate-900'
                }`}
              >
                7 天
              </button>
              <button
                id="range_14d_btn"
                onClick={() => handleSetQuickRange(14)}
                className={`rounded-md px-2.5 py-1 text-[11px] font-semibold transition cursor-pointer ${
                  activeQuickRange === 14 ? 'bg-white text-slate-900 shadow-xs' : 'text-slate-500 hover:text-slate-900'
                }`}
              >
                14 天
              </button>
              <button
                id="range_30d_btn"
                onClick={() => handleSetQuickRange(30)}
                className={`rounded-md px-2.5 py-1 text-[11px] font-semibold transition cursor-pointer ${
                  activeQuickRange === 30 ? 'bg-white text-slate-900 shadow-xs' : 'text-slate-500 hover:text-slate-900'
                }`}
              >
                30 天
              </button>
            </div>
          </div>

          {/* Custom Date Range Picker */}
          <div className="flex items-center gap-1.5 rounded-lg border border-slate-100 bg-slate-50/50 px-2.5 py-1">
            <input
              id="trend_start_date"
              type="date"
              value={startDateStr}
              onChange={(e) => setStartDateStr(e.target.value)}
              className="bg-transparent text-[11px] font-bold text-slate-700 focus:outline-none cursor-pointer"
            />
            <span className="text-[10px] text-slate-400 font-bold">至</span>
            <input
              id="trend_end_date"
              type="date"
              value={endDateStr}
              onChange={(e) => setEndDateStr(e.target.value)}
              className="bg-transparent text-[11px] font-bold text-slate-700 focus:outline-none cursor-pointer"
            />
          </div>

          {/* Metric type selection */}
          <div className="flex rounded-lg bg-slate-100 p-0.5">
            <button
              id="metric_qty_btn"
              onClick={() => setMetricType('quantity')}
              className={`rounded-md px-2.5 py-1 text-[11px] font-semibold transition cursor-pointer ${
                metricType === 'quantity' ? 'bg-white text-slate-900 shadow-xs' : 'text-slate-500 hover:text-slate-900'
              }`}
            >
              數量
            </button>
            <button
              id="metric_cost_btn"
              onClick={() => setMetricType('cost')}
              className={`rounded-md px-2.5 py-1 text-[11px] font-semibold transition cursor-pointer ${
                metricType === 'cost' ? 'bg-white text-slate-900 shadow-xs' : 'text-slate-500 hover:text-slate-900'
              }`}
            >
              金額
            </button>
          </div>
        </div>
      </div>

      {/* Chart View */}
      <div className="h-[360px] w-full">
        {trendData.length === 0 ? (
          <div className="flex h-full flex-col items-center justify-center text-slate-400">
            <HelpCircle className="h-8 w-8 stroke-[1.5] mb-2" />
            <p className="text-xs">目前暫無足夠的數據繪製趨勢圖</p>
          </div>
        ) : (
          <ResponsiveContainer width="100%" height="100%">
            <BarChart data={trendData} margin={{ top: 10, right: 10, left: -10, bottom: 5 }}>
              <CartesianGrid strokeDasharray="3 3" vertical={false} stroke="#f1f5f9" />
              <XAxis 
                dataKey="dateStr" 
                tickLine={false} 
                axisLine={false}
                tick={{ fontSize: 11, fill: '#64748b', fontWeight: 500 }} 
              />
              <YAxis 
                tickLine={false} 
                axisLine={false}
                tick={{ fontSize: 11, fill: '#64748b' }} 
                tickFormatter={(val) => metricType === 'cost' ? `$${val}` : String(val)}
              />
              <Tooltip content={renderCustomTooltip} cursor={{ fill: '#f8fafc' }} />
              <Legend 
                verticalAlign="top" 
                height={36} 
                iconType="circle"
                iconSize={8}
                wrapperStyle={{ fontSize: 11, fontWeight: 500 }}
              />
              
              {metricType === 'quantity' ? (
                <>
                  <Bar name="補貨量" dataKey="supply" fill={COLORS.supply} radius={[4, 4, 0, 0]} maxBarSize={22} />
                  <Bar name="消耗量" dataKey="consumption" fill={COLORS.consumption} radius={[4, 4, 0, 0]} maxBarSize={22} />
                  <Bar name="報廢量" dataKey="wastage" fill={COLORS.wastage} radius={[4, 4, 0, 0]} maxBarSize={22} />
                </>
              ) : (
                <>
                  <Bar name="補貨材料價值" dataKey="supplyCost" fill={COLORS.supply} radius={[4, 4, 0, 0]} maxBarSize={22} />
                  <Bar name="消耗材料價值" dataKey="consumptionCost" fill={COLORS.consumption} radius={[4, 4, 0, 0]} maxBarSize={22} />
                  <Bar name="報廢損失金額" dataKey="wastageCost" fill={COLORS.wastage} radius={[4, 4, 0, 0]} maxBarSize={22} />
                </>
              )}
            </BarChart>
          </ResponsiveContainer>
        )}
      </div>
    </div>
  );
}

export function DataBreakdownChart({ logs, fruits }: DashboardChartsProps) {
  const [breakdownTab, setBreakdownTab] = useState<'popularity' | 'wastage'>('popularity');

  const consumptionPopularityData = useMemo(() => {
    const fruitTotals: Record<string, { name: string; value: number; cost: number; color: string }> = {};
    
    fruits.forEach(f => {
      fruitTotals[f.id] = { name: f.name.split(' ')[0], value: 0, cost: 0, color: f.color };
    });

    // Accumulate only consumption logs
    logs.forEach(log => {
      if (log.type === 'consumption' && fruitTotals[log.fruitId]) {
        fruitTotals[log.fruitId].value += log.quantity;
        fruitTotals[log.fruitId].cost += log.cost;
      }
    });

    // Filter out fruits with 0 consumption and map to array
    return Object.values(fruitTotals)
      .filter(f => f.value > 0)
      .sort((a, b) => b.value - a.value);
  }, [logs, fruits]);

  const fruitWastageBreakdownData = useMemo(() => {
    const fruitTotals: Record<string, { name: string; quantity: number; cost: number; color: string }> = {};

    fruits.forEach(f => {
      fruitTotals[f.id] = { name: f.name.split(' ')[0], quantity: 0, cost: 0, color: f.color };
    });

    logs.forEach(log => {
      if (log.type === 'wastage' && fruitTotals[log.fruitId]) {
        fruitTotals[log.fruitId].quantity += log.quantity;
        fruitTotals[log.fruitId].cost += log.cost;
      }
    });

    return Object.values(fruitTotals)
      .filter(f => f.quantity > 0)
      .sort((a, b) => b.quantity - a.quantity);
  }, [logs, fruits]);

  const renderPieTooltip = ({ active, payload }: any) => {
    if (active && payload && payload.length) {
      const data = payload[0].payload as { name: string; value: number; cost: number; percent: number };
      const percentVal = (payload[0].value || 0);
      return (
        <div className="rounded-xl border border-slate-100 bg-white p-3 shadow-lg text-xs">
          <p className="font-bold text-slate-800 mb-1">{data.name}</p>
          <div className="space-y-1">
            <div className="flex justify-between gap-4">
              <span className="text-slate-500">累計消耗：</span>
              <span className="font-bold text-slate-900">{data.value} 個</span>
            </div>
            <div className="flex justify-between gap-4">
              <span className="text-slate-500">佔比：</span>
              <span className="font-bold text-indigo-600">{percentVal.toFixed(1)}%</span>
            </div>
            <div className="flex justify-between gap-4 border-t border-slate-50 pt-1 mt-1">
              <span className="text-slate-500">材料價值：</span>
              <span className="font-bold text-slate-700">{formatCurrency(data.cost)}</span>
            </div>
          </div>
        </div>
      );
    }
    return null;
  };

  return (
    <div id="breakdown_chart_card" className="rounded-2xl border border-slate-100 bg-white p-6 shadow-sm h-full flex flex-col justify-between">
      <div className="mb-5 flex flex-col gap-3">
        <div className="flex items-center justify-between">
          <h3 className="flex items-center gap-2 text-md font-semibold text-slate-900">
            <PieIcon className="h-5 w-5 text-indigo-500" />
            數據細項剖析
          </h3>
        </div>

        {/* Toggle buttons for breakdown view */}
        <div className="flex rounded-xl bg-slate-100/80 p-1">
          <button
            id="breakdown_pop_btn"
            onClick={() => setBreakdownTab('popularity')}
            className={`w-1/2 rounded-lg py-1.5 text-center text-xs font-semibold transition cursor-pointer ${
              breakdownTab === 'popularity' ? 'bg-white text-indigo-600 shadow-sm' : 'text-slate-500 hover:text-slate-900'
            }`}
          >
            熱門水果佔比
          </button>
          <button
            id="breakdown_waste_btn"
            onClick={() => setBreakdownTab('wastage')}
            className={`w-1/2 rounded-lg py-1.5 text-center text-xs font-semibold transition cursor-pointer ${
              breakdownTab === 'wastage' ? 'bg-white text-rose-600 shadow-sm' : 'text-slate-500 hover:text-slate-900'
            }`}
          >
            報廢品項排行
          </button>
        </div>
      </div>

      {/* Render Breakdown Tab Content */}
      <div className="flex-1 flex flex-col justify-center min-h-[320px]">
        {breakdownTab === 'popularity' ? (
          consumptionPopularityData.length === 0 ? (
            <div className="flex h-full flex-col items-center justify-center text-slate-400">
              <HelpCircle className="h-8 w-8 stroke-[1.5] mb-2" />
              <p className="text-xs">尚無任何客人食用統計</p>
            </div>
          ) : (
            <div className="flex h-full flex-col justify-center">
              <div className="h-[180px] w-full relative">
                <ResponsiveContainer width="100%" height="100%">
                  <PieChart>
                    <Pie
                      data={consumptionPopularityData}
                      cx="50%"
                      cy="50%"
                      innerRadius={50}
                      outerRadius={75}
                      paddingAngle={3}
                      dataKey="value"
                    >
                      {consumptionPopularityData.map((entry, index) => (
                        <Cell key={`cell-${index}`} fill={entry.color} />
                      ))}
                    </Pie>
                    <Tooltip content={renderPieTooltip} />
                  </PieChart>
                </ResponsiveContainer>
                <div className="absolute inset-0 flex flex-col items-center justify-center pointer-events-none">
                  <span className="text-xs text-slate-400">總消耗水果</span>
                  <span className="text-xl font-bold text-slate-800">
                    {consumptionPopularityData.reduce((acc, curr) => acc + curr.value, 0)} 個
                  </span>
                </div>
              </div>

              {/* Legend list with custom values */}
              <div className="mt-4 max-h-[110px] overflow-y-auto space-y-1.5 pr-1">
                {consumptionPopularityData.map((entry, idx) => {
                  const total = consumptionPopularityData.reduce((acc, curr) => acc + curr.value, 0);
                  const percent = total > 0 ? (entry.value / total) * 100 : 0;
                  return (
                    <div key={idx} className="flex items-center justify-between text-xs">
                      <div className="flex items-center gap-1.5 text-slate-600">
                        <span className="h-2 w-2 rounded-full" style={{ backgroundColor: entry.color }} />
                        <span className="font-medium truncate max-w-[100px]">{entry.name}</span>
                      </div>
                      <div className="flex items-center gap-2 font-semibold">
                        <span className="text-slate-400 font-normal">{entry.value}個</span>
                        <span className="text-slate-800">{percent.toFixed(0)}%</span>
                      </div>
                    </div>
                  );
                })}
              </div>
            </div>
          )
        ) : (
          fruitWastageBreakdownData.length === 0 ? (
            <div className="flex h-full flex-col items-center justify-center text-slate-400">
              <HelpCircle className="h-8 w-8 stroke-[1.5] mb-2" />
              <p className="text-xs">尚無任何報廢損耗統計</p>
            </div>
          ) : (
            <div className="flex h-full flex-col justify-center space-y-4">
              <div className="text-center pb-2 border-b border-slate-50">
                <p className="text-xs text-slate-400">累積報廢總量</p>
                <p className="text-xl font-extrabold text-rose-600">
                  {fruitWastageBreakdownData.reduce((acc, curr) => acc + curr.quantity, 0)} 個
                </p>
              </div>
              
              <div className="flex-1 overflow-y-auto pr-1 space-y-3.5">
                {fruitWastageBreakdownData.map((entry, idx) => {
                  const total = fruitWastageBreakdownData.reduce((acc, curr) => acc + curr.quantity, 0);
                  const percent = total > 0 ? (entry.quantity / total) * 100 : 0;

                  return (
                    <div key={idx} className="space-y-1.5 text-xs">
                      <div className="flex justify-between font-medium">
                        <span className="text-slate-700 font-semibold truncate max-w-[180px]">
                          {entry.name}
                        </span>
                        <span className="text-slate-500 font-semibold">
                          {entry.quantity} 個 ({percent.toFixed(0)}%)
                        </span>
                      </div>
                      
                      <div className="h-2 w-full rounded-full bg-slate-100 overflow-hidden">
                        <div 
                          className="h-full rounded-full transition-all" 
                          style={{ width: `${percent}%`, backgroundColor: entry.color }}
                        />
                      </div>
                      
                      <div className="flex justify-end">
                        <span className="text-[10px] text-slate-400 font-medium">
                          估計損失：{formatCurrency(entry.cost)}
                        </span>
                      </div>
                    </div>
                  );
                })}
              </div>
            </div>
          )
        )}
      </div>
    </div>
  );
}
