/**
 * @license
 * SPDX-License-Identifier: Apache-2.0
 */

export interface FruitType {
  id: string;
  name: string;       // e.g. 蘋果, 香蕉
  unit: string;       // e.g. 個, 顆, 包, 串
  defaultCost: number; // e.g. 15 (NTD per unit)
  color: string;      // Tailwind hex/class for badges and charts
}

export type LogType = 'supply' | 'consumption' | 'wastage';

export interface LogEntry {
  id: string;
  timestamp: number;  // unix timestamp in ms
  fruitId: string;
  type: LogType;
  quantity: number;
  cost: number;       // quantity * defaultCost at that time
  reason?: string;    // for wastage, e.g. 過熟變軟, 碰撞受損, 例行清理
  notes?: string;     // custom comments
}

export interface InventoryItem {
  fruitId: string;
  currentDisplay: number; // current quantity available in lobby
  totalSupplied: number;
  totalConsumed: number;
  totalWasted: number;
}

export const DEFAULT_FRUITS: FruitType[] = [
  { id: 'apple', name: '蘋果 (Apple)', unit: '個', defaultCost: 15, color: '#f87171' }, // Red-400
  { id: 'banana', name: '香蕉 (Banana)', unit: '根', defaultCost: 10, color: '#facc15' }, // Yellow-400
  { id: 'orange', name: '柳橙 (Orange)', unit: '個', defaultCost: 12, color: '#fb923c' }, // Orange-400
  { id: 'pear', name: '梨子 (Pear)', unit: '個', defaultCost: 25, color: '#a3e635' }, // Lime-400
  { id: 'kiwi', name: '奇異果 (Kiwi)', unit: '個', defaultCost: 18, color: '#4ade80' }, // Green-400
  { id: 'grape', name: '葡萄 (Grape)', unit: '串', defaultCost: 40, color: '#c084fc' }, // Purple-400
];

export const WASTE_REASONS = [
  '過熟變軟 (Overripe)',
  '碰撞受損 (Bruised)',
  '表面發霉 (Moldy)',
  '例行清理更換 (Routine Replacement)',
  '外觀不佳/瑕疵 (Blemished)',
  '其他原因 (Other)',
];
